# BANCA 2.0 — continuidade 0.4.7

Projeto Android Kotlin com Jetpack Compose, Material 3 e Room/SQLite.
Módulos preservados: `app`, `core`, `database` e `statistics`.

## Escopo desta continuidade
Esta rodada prioriza a evolução da captura MediaProjection e da Banca Intelligence offline. Não implementa ainda ROI, reconhecimento AZUL/VERMELHO/EMPATE, deduplicação visual ou integração de leituras reconhecidas ao Room; esses itens ficam para a próxima etapa.

## Captura de tela — implementação 0.4.5
- Solicita autorização pelo fluxo oficial `MediaProjectionManager.createScreenCaptureIntent()`.
- Serviço não exportado em primeiro plano, com tipo `mediaProjection` e notificação contínua.
- Usa `VirtualDisplay` + `ImageReader`; callbacks e amostragem de pixels executados em `HandlerThread`, fora da thread principal.
- Processa amostras esparsas do quadro real e calcula RGB médio, dimensões e quantidade de amostras.
- Envia apenas telemetria agregada para a Activity; não persiste screenshots nem buffers de pixels.
- Registra início, interrupção pelo sistema, falhas e encerramento em Logcat; libera VirtualDisplay, ImageReader, callback, MediaProjection e thread.
- Evita criar outro VirtualDisplay quando a projeção já está ativa e retorna `START_NOT_STICKY`.

**Limites ainda existentes:** a telemetria RGB não é um recognizer. ROI, rotação/redimensionamento dinâmico durante a sessão, classificação visual e validação em aparelho/emulador ainda não foram concluídos. A permissão precisa ser concedida pelo usuário em cada nova sessão conforme as regras Android.

## Banca Intelligence offline — implementação 0.4.5
- Usa exclusivamente rodadas confirmadas já observadas no Room; não envia dados à rede.
- Mantém a ordem de entrada mais recente primeiro, conforme `RoundDao.observeAll()`.
- Relata frequências do histórico e janelas recentes de 10, 20 e 50 resultados, quando disponíveis.
- Responde perguntas sobre frequências, alternâncias, maior sequência, último resultado, empates e comparação dos dois períodos mais recentes de 10.
- Informa quando a comparação exige ao menos 20 resultados e quando a amostra é pequena.
- Ignora códigos inválidos e não apresenta previsão do próximo resultado.
- Não é um LLM: é um componente local determinístico baseado em estatística descritiva.

## Funcionalidades existentes preservadas
- Registro manual, histórico e estatísticas descritivas.
- Motor experimental de sinais com estado `SEM_SINAL`.
- Importação/exportação CSV.
- Backup JSON versionado das cinco tabelas Room e restauração transacional.
- Migração Room 1→2.
- Probabilidade teórica do modelo de dois dados por lado separada de frequências observadas.

## Compilação e ambiente
Configuração: AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, compileSdk 35, minSdk 26.
O ZIP de origem não contém Gradle Wrapper nem JARs do wrapper. O ambiente desta execução possui OpenJDK 21 e `kotlinc`, mas não possui Gradle, JDK 17, Android SDK ou `adb`; a tentativa anterior de obter Gradle foi bloqueada por falha DNS. O componente Kotlin puro da Intelligence foi compilado isoladamente e passou por cinco smoke checks; os testes JUnit/Gradle e a compilação Android não foram executados nem declarados aprovados.
O workflow `.github/workflows/android-ci.yml` permanece preparado para executar testes unitários e gerar APK Debug no GitHub Actions. A execução remota depende de publicar o projeto em um repositório GitHub.

## Próximas tarefas
1. Gerar/adicionar o Gradle Wrapper oficial e comprovar `test` + `assembleDebug` no CI.
2. Validar a captura em Android 14/15 físico ou emulador, inclusive início, parada, revogação de permissão e mudança de orientação.
3. Implementar ROI configurável e recognizer calibrável sobre quadros capturados.
4. Integrar leituras, revisão manual e histórico ao Room.

Frequências históricas descrevem observações passadas e não preveem resultados futuros. Backup JSON não é criptografado; armazene-o em local privado.

## Novo em 0.4.6 — núcleo de visão (Kotlin puro, módulo `core`, pacote `br.com.banca.core.vision`)
- `Roi`: região em coordenadas normalizadas (0..1), validação (invertida, fora da tela, pequena demais), conversão para pixels em qualquer resolução, movimentação com limites e serialização.
- `ColorRecognizer`: classifica AZUL/VERMELHO/EMPATE por matiz HSV dentro da ROI, com limiares configuráveis, ambiguidade e rejeição de leituras incertas. A `confidence` é a dominância da cor entre os pixels coloridos (escore heurístico, **sem precisão medida**). As cores de referência são estimativas e precisam de calibração com a tela real.
- `ResultTracker`: estados DETECTED/PENDING/CONFIRMED/REJECTED/UNCERTAIN, estabilidade por quadros e tempo, cooldown, fila de pendentes com confirmação/rejeição manual, tratamento de oscilação e de captura interrompida.
- 3 arquivos de teste JUnit (ROI, reconhecedor, rastreador) com quadros sintéticos. **Escritos mas NÃO executados** (sem Gradle/Kotlin neste ambiente).
- Workflow CI corrigido: gera o Gradle Wrapper quando ausente, roda test/assembleDebug/assembleRelease, envia logs, relatórios e APKs como artifacts. **Ainda não executado.**
- **Não integrado:** o `ScreenCaptureService` ainda não usa Roi/ColorRecognizer/ResultTracker; não há tela de calibração, persistência da ROI, ligação ao Room nem evolução da Intelligence.


## Continuidade 0.4.7 — correção de compilação Kotlin
- Corrigida a inclusão de eventos na fila manual do `ResultTracker`, usando a operação compatível `ArrayDeque.add`.
- Versão de trabalho incrementada para 0.4.7 (`versionCode` 11).
- Verificação local com `kotlinc` dos módulos Kotlin puros `core` e `statistics`.
- Teste de fumaça executado para ROI, reconhecimento HSV sintético, confirmação manual pendente e probabilidades teóricas Bac Bo.
- A compilação Android/Gradle e os testes JUnit/Room ainda dependem de JDK 17, Gradle 8.9/Wrapper e Android SDK 35; não foram declarados como aprovados.
