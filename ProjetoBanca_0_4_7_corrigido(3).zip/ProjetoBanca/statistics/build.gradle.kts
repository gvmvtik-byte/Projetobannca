plugins { alias(libs.plugins.android.library); alias(libs.plugins.kotlin.android) }
android {
    namespace = "br.com.banca.statistics"
    compileSdk = 35
    defaultConfig { minSdk = 26 }
    testOptions { unitTests.isReturnDefaultValues = true }
}
dependencies { testImplementation(libs.junit) }
