package br.com.banca.statistics

import org.junit.Assert.*
import org.junit.Test

class StatisticsEngineTest {
    @Test fun countsOnlyKnownOutcomes() {
        val result = StatisticsEngine.count(listOf("A", "V", "E", "?", "A"))
        assertEquals(2, result.blue); assertEquals(1, result.red)
        assertEquals(1, result.tie); assertEquals(4, result.total)
        assertEquals(50.0, result.percent(result.blue), 0.001)
    }

    @Test fun emptyHistoryHasZeroPercentages() {
        val result = StatisticsEngine.count(emptyList())
        assertEquals(0, result.total); assertEquals(0.0, result.percent(0), 0.0)
    }

    @Test fun streakUsesNewestFirstOrder() {
        assertEquals("A" to 3, StatisticsEngine.streak(listOf("A", "A", "A", "V")))
        assertEquals(null to 0, StatisticsEngine.streak(emptyList()))
    }

    @Test fun windowCalculatesAlternationsAndLongestStreak() {
        val result = StatisticsEngine.window(listOf("A", "A", "V", "E", "E"), 5)
        assertEquals(2, result.alternations)
        assertEquals(2, result.longestStreak)
        assertEquals(5, result.counts.total)
    }

    @Test(expected = IllegalArgumentException::class)
    fun windowRejectsNonPositiveSize() { StatisticsEngine.window(emptyList(), 0) }
}
