package br.com.banca.statistics

import org.junit.Assert.*
import org.junit.Test

class StatisticalInferenceTest {
    @Test fun wilsonIntervalContainsEstimateAndStaysBounded() {
        val result = StatisticalInference.wilsonInterval(60, 100)
        assertEquals(0.60, result.estimate, 1e-12)
        assertTrue(result.lower in 0.0..result.estimate)
        assertTrue(result.upper in result.estimate..1.0)
        assertEquals(100, result.sampleSize)
    }

    @Test fun emptySampleHasNoArtificialEstimate() {
        val result = StatisticalInference.wilsonInterval(0, 0)
        assertEquals(0.0, result.estimate, 0.0)
        assertEquals(0.0, result.lower, 0.0)
        assertEquals(0.0, result.upper, 0.0)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsSuccessesAboveSample() { StatisticalInference.wilsonInterval(4, 3) }

    @Test fun comparesObservedSharesBetweenPeriods() {
        val result = StatisticalInference.comparePeriods(listOf("A", "A", "V", "E"), listOf("A", "V", "V", "V"))
        assertEquals(4, result.firstSampleSize)
        assertEquals(4, result.secondSampleSize)
        assertEquals(-0.25, result.blueShareDifference!!, 1e-12)
        assertEquals(0.50, result.redShareDifference!!, 1e-12)
        assertEquals(-0.25, result.tieShareDifference!!, 1e-12)
    }
}
