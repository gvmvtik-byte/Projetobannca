package br.com.banca.statistics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BacBoProbabilitiesTest {
    @Test fun standardTwoDicePerSideHasExactExpectedDistribution() {
        val p = BacBoProbabilities.standardTwoDicePerSide()
        assertEquals(575, p.blue.favorableCases)
        assertEquals(575, p.red.favorableCases)
        assertEquals(146, p.tie.favorableCases)
        assertEquals(1296, p.blue.totalCases)
        assertEquals(1296, p.red.totalCases)
        assertEquals(1296, p.tie.totalCases)
        assertEquals(1.0, p.blue.probability + p.red.probability + p.tie.probability, 1e-12)
        assertTrue(p.tie.probability > 0.0)
    }
}
