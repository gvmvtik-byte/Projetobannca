package br.com.banca.statistics

import org.junit.Assert.*
import org.junit.Test

class SignalEngineTest {
    @Test fun insufficientDataReturnsNoSignal() {
        val result = SignalEngine.analyze(listOf("A", "A", "A"))
        assertEquals(SignalState.SEM_SINAL, result.state)
    }

    @Test fun historicalConcentrationIsExplicitlyExperimental() {
        val result = SignalEngine.analyze(List(40) { "A" } + List(10) { "V" })
        assertEquals(SignalState.EXPERIMENTAL, result.state)
        assertEquals("A", result.outcome)
        assertTrue(result.explanation.contains("Não prevê"))
    }

    @Test fun balancedHistoryReturnsNoSignal() {
        val result = SignalEngine.analyze(List(50) { listOf("A", "V", "E")[it % 3] })
        assertEquals(SignalState.SEM_SINAL, result.state)
    }
}
