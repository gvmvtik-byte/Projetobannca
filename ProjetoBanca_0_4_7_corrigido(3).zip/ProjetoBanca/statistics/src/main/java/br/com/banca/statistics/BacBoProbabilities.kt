package br.com.banca.statistics

/**
 * Exact baseline for standard Bac Bo: each side independently rolls two fair six-sided dice;
 * the higher sum wins and equal sums are a tie. This is theoretical, not estimated from history.
 */
data class TheoreticalProbability(val favorableCases: Int, val totalCases: Int) {
    val probability: Double get() = favorableCases.toDouble() / totalCases
    val percent: Double get() = probability * 100.0
}

data class BacBoTheoreticalProbabilities(
    val blue: TheoreticalProbability,
    val red: TheoreticalProbability,
    val tie: TheoreticalProbability
)

object BacBoProbabilities {
    fun standardTwoDicePerSide(): BacBoTheoreticalProbabilities {
        val frequencies = (1..6).flatMap { a -> (1..6).map { b -> a + b } }
            .groupingBy { it }.eachCount()
        var blueWins = 0
        var redWins = 0
        var ties = 0
        for ((blueTotal, blueWays) in frequencies) {
            for ((redTotal, redWays) in frequencies) {
                val combinations = blueWays * redWays
                when {
                    blueTotal > redTotal -> blueWins += combinations
                    blueTotal < redTotal -> redWins += combinations
                    else -> ties += combinations
                }
            }
        }
        val total = 36 * 36
        return BacBoTheoreticalProbabilities(
            TheoreticalProbability(blueWins, total),
            TheoreticalProbability(redWins, total),
            TheoreticalProbability(ties, total)
        )
    }
}
