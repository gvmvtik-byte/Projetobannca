package br.com.banca.statistics

enum class SignalState { SEM_SINAL, EXPERIMENTAL }

data class ExperimentalSignal(
    val state: SignalState,
    val outcome: String? = null,
    val strategy: String? = null,
    val sampleSize: Int,
    val observedShare: Double? = null,
    val explanation: String
)

/**
 * Baseline demonstrator, not a betting recommendation or a predictive model.
 * It emits no signal unless the historical sample is large and concentration is high.
 * Past frequency does not make an outcome more likely in the next independent round.
 */
object SignalEngine {
    fun analyze(outcomesNewestFirst: List<String>, minimumSamples: Int = 50, threshold: Double = 0.60): ExperimentalSignal {
        require(minimumSamples >= 1)
        require(threshold in (1.0 / 3.0)..1.0)
        val counts = StatisticsEngine.count(outcomesNewestFirst)
        if (counts.total < minimumSamples) {
            return ExperimentalSignal(SignalState.SEM_SINAL, sampleSize = counts.total,
                explanation = "Amostra insuficiente: são necessários $minimumSamples registros válidos.")
        }
        val candidates = listOf("A" to counts.blue, "V" to counts.red, "E" to counts.tie)
        val top = candidates.maxBy { it.second }
        val share = top.second.toDouble() / counts.total
        if (share < threshold) {
            return ExperimentalSignal(SignalState.SEM_SINAL, sampleSize = counts.total,
                observedShare = share, explanation = "Não há concentração histórica suficiente para o critério experimental.")
        }
        return ExperimentalSignal(SignalState.EXPERIMENTAL, top.first, "FREQUENCIA_HISTORICA",
            counts.total, share,
            "Critério descritivo experimental: concentração histórica de ${"%.1f".format(java.util.Locale.ROOT, share * 100)}%. Não prevê a próxima rodada.")
    }
}
