package br.com.banca.statistics

import kotlin.math.sqrt

data class OutcomeCounts(val blue: Int, val red: Int, val tie: Int, val total: Int) {
    fun percent(value: Int): Double = if (total == 0) 0.0 else value * 100.0 / total
}

data class WindowStats(
    val counts: OutcomeCounts,
    val blueVariance: Double,
    val redVariance: Double,
    val tieVariance: Double,
    val alternations: Int,
    val longestStreak: Int
)

object StatisticsEngine {
    private val valid = setOf("A", "V", "E")

    /** Counts only recognized outcomes. Unknown values are ignored, never silently classified. */
    fun count(outcomes: List<String>): OutcomeCounts {
        val clean = outcomes.filter { it in valid }
        return OutcomeCounts(clean.count { it == "A" }, clean.count { it == "V" },
            clean.count { it == "E" }, clean.size)
    }

    /** Input order is newest first, matching RoundDao.latest(). */
    fun streak(outcomesNewestFirst: List<String>): Pair<String?, Int> {
        val first = outcomesNewestFirst.firstOrNull()?.takeIf { it in valid } ?: return null to 0
        return first to outcomesNewestFirst.takeWhile { it == first }.size
    }

    fun window(outcomesNewestFirst: List<String>, size: Int): WindowStats {
        require(size > 0) { "Window size must be positive" }
        val values = outcomesNewestFirst.filter { it in valid }.take(size)
        val counts = count(values)
        val (blueVariance, redVariance, tieVariance) = listOf("A", "V", "E").map { code ->
            if (values.isEmpty()) 0.0 else {
                val p = values.count { it == code }.toDouble() / values.size
                p * (1.0 - p)
            }
        }
        val alternations = values.zipWithNext().count { (a, b) -> a != b }
        var longest = 0
        var current = 0
        var previous: String? = null
        values.forEach { value ->
            current = if (value == previous) current + 1 else 1
            if (current > longest) longest = current
            previous = value
        }
        return WindowStats(counts, blueVariance, redVariance, tieVariance, alternations, longest)
    }

    fun standardError(observedRate: Double, sampleSize: Int): Double {
        require(observedRate in 0.0..1.0 && sampleSize >= 0)
        return if (sampleSize == 0) 0.0 else sqrt(observedRate * (1.0 - observedRate) / sampleSize)
    }
}
