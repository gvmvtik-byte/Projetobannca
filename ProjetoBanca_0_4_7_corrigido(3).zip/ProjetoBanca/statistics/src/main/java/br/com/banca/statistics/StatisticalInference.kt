package br.com.banca.statistics

import kotlin.math.sqrt

/** Wilson score interval for a binomial proportion. It describes uncertainty in a sample,
 * not the probability of a future independent game outcome. */
data class ProportionInterval(
    val estimate: Double,
    val lower: Double,
    val upper: Double,
    val sampleSize: Int,
    val confidenceLevel: Double
)

object StatisticalInference {
    fun wilsonInterval(successes: Int, sampleSize: Int, confidenceLevel: Double = 0.95): ProportionInterval {
        require(sampleSize >= 0) { "Amostra não pode ser negativa" }
        require(successes in 0..sampleSize) { "Sucessos devem estar entre zero e o tamanho da amostra" }
        require(confidenceLevel in setOf(0.80, 0.90, 0.95, 0.98, 0.99, 0.999)) { "Nível de confiança não suportado" }
        if (sampleSize == 0) return ProportionInterval(0.0, 0.0, 0.0, 0, confidenceLevel)
        val z = when {
            confidenceLevel >= 0.999 -> 3.290526731
            confidenceLevel >= 0.99 -> 2.575829304
            confidenceLevel >= 0.98 -> 2.326347874
            confidenceLevel >= 0.95 -> 1.959963985
            confidenceLevel >= 0.90 -> 1.644853627
            else -> 1.281551566
        }
        val n = sampleSize.toDouble()
        val p = successes.toDouble() / n
        val z2 = z * z
        val denominator = 1.0 + z2 / n
        val center = (p + z2 / (2.0 * n)) / denominator
        val margin = z * sqrt((p * (1.0 - p) / n) + z2 / (4.0 * n * n)) / denominator
        return ProportionInterval(p, (center - margin).coerceAtLeast(0.0),
            (center + margin).coerceAtMost(1.0), sampleSize, confidenceLevel)
    }

    /** Compares two disjoint, already-defined periods. No causal or predictive interpretation. */
    fun comparePeriods(first: List<String>, second: List<String>): PeriodComparison {
        val a = StatisticsEngine.count(first)
        val b = StatisticsEngine.count(second)
        fun share(count: Int, total: Int) = if (total == 0) null else count.toDouble() / total
        return PeriodComparison(a.total, b.total,
            difference(share(a.blue, a.total), share(b.blue, b.total)),
            difference(share(a.red, a.total), share(b.red, b.total)),
            difference(share(a.tie, a.total), share(b.tie, b.total)))
    }

    private fun difference(first: Double?, second: Double?): Double? =
        if (first == null || second == null) null else second - first
}

data class PeriodComparison(
    val firstSampleSize: Int,
    val secondSampleSize: Int,
    /** Second period minus first period, in proportion units (-1..1). */
    val blueShareDifference: Double?,
    val redShareDifference: Double?,
    val tieShareDifference: Double?
)
