package br.com.banca.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sessions")
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val startedAtEpochMillis: Long,
    val endedAtEpochMillis: Long? = null,
    val notes: String = ""
)
