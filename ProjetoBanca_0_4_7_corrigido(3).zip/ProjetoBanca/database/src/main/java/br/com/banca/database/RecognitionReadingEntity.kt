package br.com.banca.database

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A visual reading is kept separate from confirmed rounds to preserve an audit trail. */
@Entity(tableName = "recognition_readings")
data class RecognitionReadingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long? = null,
    val detectedOutcome: String? = null,
    val confidence: Double,
    val capturedAtEpochMillis: Long,
    val status: String = "PENDING",
    val details: String = ""
)
