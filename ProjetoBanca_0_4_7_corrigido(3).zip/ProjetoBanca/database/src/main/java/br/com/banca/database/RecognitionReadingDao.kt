package br.com.banca.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RecognitionReadingDao {
    @Insert suspend fun insert(reading: RecognitionReadingEntity): Long
    @Query("SELECT * FROM recognition_readings ORDER BY capturedAtEpochMillis DESC") fun observeAll(): Flow<List<RecognitionReadingEntity>>
    @Query("SELECT * FROM recognition_readings ORDER BY id") suspend fun getAll(): List<RecognitionReadingEntity>
    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE) suspend fun restoreAll(items: List<RecognitionReadingEntity>)
    @Query("DELETE FROM recognition_readings") suspend fun clearAll()
    @Query("UPDATE recognition_readings SET status = :status, detectedOutcome = :outcome WHERE id = :id") suspend fun review(id: Long, status: String, outcome: String?)
}
