package br.com.banca.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [RoundEntity::class, SessionEntity::class, RecognitionReadingEntity::class,
        SignalRecordEntity::class, AnalysisRecordEntity::class],
    version = 2,
    exportSchema = true
)
abstract class BancaDatabase : RoomDatabase() {
    abstract fun roundDao(): RoundDao
    abstract fun sessionDao(): SessionDao
    abstract fun recognitionReadingDao(): RecognitionReadingDao
    abstract fun signalRecordDao(): SignalRecordDao
    abstract fun analysisRecordDao(): AnalysisRecordDao

    companion object {
        /** Additive migration: existing manually registered rounds are preserved. */
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, startedAtEpochMillis INTEGER NOT NULL, endedAtEpochMillis INTEGER, notes TEXT NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS recognition_readings (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, sessionId INTEGER, detectedOutcome TEXT, confidence REAL NOT NULL, capturedAtEpochMillis INTEGER NOT NULL, status TEXT NOT NULL, details TEXT NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS signal_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, sessionId INTEGER, strategy TEXT NOT NULL, suggestedOutcome TEXT, createdAtEpochMillis INTEGER NOT NULL, sampleSize INTEGER NOT NULL, observedShare REAL, state TEXT NOT NULL, evaluatedOutcome TEXT, evaluatedAtEpochMillis INTEGER)")
                db.execSQL("CREATE TABLE IF NOT EXISTS analysis_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, createdAtEpochMillis INTEGER NOT NULL, analysisType TEXT NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL)")
            }
        }
    }
}
