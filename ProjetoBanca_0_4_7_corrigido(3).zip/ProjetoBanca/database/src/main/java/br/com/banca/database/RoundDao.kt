package br.com.banca.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RoundDao {
    @Insert suspend fun insert(round: RoundEntity): Long
    @Insert suspend fun insertAll(rounds: List<RoundEntity>): List<Long>
    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE) suspend fun restoreAll(rounds: List<RoundEntity>)
    @Query("SELECT * FROM rounds ORDER BY id") suspend fun getAll(): List<RoundEntity>
    @Query("DELETE FROM rounds") suspend fun clearAll()
    @Query("SELECT * FROM rounds ORDER BY recordedAtEpochMillis DESC, id DESC")
    fun observeAll(): Flow<List<RoundEntity>>
    @Query("SELECT * FROM rounds ORDER BY recordedAtEpochMillis DESC, id DESC LIMIT :limit")
    suspend fun latest(limit: Int): List<RoundEntity>
    @Query("SELECT COUNT(*) FROM rounds") fun count(): Flow<Int>
    @Query("DELETE FROM rounds") suspend fun deleteAll()
}
