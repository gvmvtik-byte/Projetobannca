package br.com.banca.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {
    @Insert suspend fun insert(session: SessionEntity): Long
    @Query("SELECT * FROM sessions ORDER BY startedAtEpochMillis DESC") fun observeAll(): Flow<List<SessionEntity>>
    @Query("UPDATE sessions SET endedAtEpochMillis = :endedAt WHERE id = :id") suspend fun close(id: Long, endedAt: Long)
    @Query("SELECT * FROM sessions ORDER BY id") suspend fun getAll(): List<SessionEntity>
    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE) suspend fun restoreAll(items: List<SessionEntity>)
    @Query("DELETE FROM sessions") suspend fun clearAll()
    @Query("SELECT * FROM sessions WHERE id = :id LIMIT 1") suspend fun get(id: Long): SessionEntity?
}
