package br.com.banca.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "signal_records")
data class SignalRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long? = null,
    val strategy: String,
    val suggestedOutcome: String?,
    val createdAtEpochMillis: Long,
    val sampleSize: Int,
    val observedShare: Double?,
    val state: String,
    val evaluatedOutcome: String? = null,
    val evaluatedAtEpochMillis: Long? = null
)
