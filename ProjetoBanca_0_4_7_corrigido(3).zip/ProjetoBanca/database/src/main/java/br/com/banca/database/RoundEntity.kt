package br.com.banca.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rounds")
data class RoundEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val outcome: String,
    val recordedAtEpochMillis: Long,
    val source: String = "MANUAL",
    val confirmed: Boolean = true
)
