package br.com.banca.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SignalRecordDao {
    @Insert suspend fun insert(record: SignalRecordEntity): Long
    @Query("SELECT * FROM signal_records ORDER BY createdAtEpochMillis DESC") fun observeAll(): Flow<List<SignalRecordEntity>>
    @Query("SELECT * FROM signal_records ORDER BY id") suspend fun getAll(): List<SignalRecordEntity>
    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE) suspend fun restoreAll(items: List<SignalRecordEntity>)
    @Query("DELETE FROM signal_records") suspend fun clearAll()
    @Query("UPDATE signal_records SET evaluatedOutcome = :outcome, evaluatedAtEpochMillis = :at WHERE id = :id") suspend fun evaluate(id: Long, outcome: String, at: Long)
}
