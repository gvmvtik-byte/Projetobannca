package br.com.banca.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AnalysisRecordDao {
    @Insert suspend fun insert(record: AnalysisRecordEntity): Long
    @Query("SELECT * FROM analysis_records ORDER BY id") suspend fun getAll(): List<AnalysisRecordEntity>
    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE) suspend fun restoreAll(items: List<AnalysisRecordEntity>)
    @Query("DELETE FROM analysis_records") suspend fun clearAll()
    @Query("SELECT * FROM analysis_records ORDER BY createdAtEpochMillis DESC") fun observeAll(): Flow<List<AnalysisRecordEntity>>
}
