# BANCA 2.0 — relatório de continuidade
Data: 2026-11-26
Versão de trabalho: **0.4.2** (base recebida 0.4.1 preservada)

## Auditoria da origem 0.4.0
- ZIP extraído; os 79 itens do arquivo foram listados e os arquivos de código, Gradle, manifestos, testes, README e PROGRESSO foram examinados.
- Preservados os módulos `app`, `core`, `database` e `statistics`.
- Confirmados registro manual, histórico, estatísticas, motor experimental, CSV, cinco tabelas Room e migração 1→2.
- O README de origem estava desatualizado (rotulava o projeto como 0.3.0 e dizia que o backup completo não existia); o código e o PROGRESSO confirmam o backup 0.4.0.

## Alterações realizadas nesta continuidade 0.4.2
- [x] Validação do backup extraída para `DatabaseBackup.validate`, permitindo testes independentes do parser JSON.
- [x] IDs devem ser positivos e únicos dentro de cada tabela.
- [x] Referências opcionais de sessão em leituras e sinais devem apontar para sessões existentes.
- [x] Datas de encerramento de sessão não podem anteceder o início.
- [x] Resultados em leituras e sinais limitados a A/V/E quando presentes.
- [x] Confiança e proporção observada devem ser valores finitos entre 0 e 1; tamanho da amostra não pode ser negativo.
- [x] Importação de backup limitada a 20 MiB durante a leitura do SAF, evitando carregar arquivos ilimitados antes da validação.
- [x] Adicionados testes unitários para backup vazio, IDs duplicados, referências inválidas, resultado/confiança inválidos, datas de sessão e relações válidas.
- [x] Dependência JUnit adicionada ao módulo app.
- [x] Probabilidades teóricas exatas adicionadas para o modelo Bac Bo padrão de dois dados justos por lado: 575/1296 Azul, 575/1296 Vermelho e 146/1296 Empate.
- [x] Distribuição teórica exibida separadamente das frequências observadas na tela de estatísticas.
- [x] Teste unitário adicionado para os 1.296 resultados equiprováveis do modelo de dois dados por lado.
- [x] Na etapa anterior, versão do aplicativo atualizada para 0.4.1 (versionCode 5).
- [x] README reescrito para refletir o estado verificado.

## Compilação e testes — resultado real
- [x] ZIP extraído e estrutura auditada.
- [x] OpenJDK 21 encontrado.
- [ ] JDK 17: não disponível/configurado.
- [ ] Gradle: não instalado.
- [ ] Gradle Wrapper: ausente na origem; não foi possível baixar os artefatos oficiais porque o ambiente não resolve `services.gradle.org` (falha DNS).
- [ ] Android SDK Platform 35: não encontrado.
- [ ] `adb`: não encontrado.
- [ ] `./gradlew test`: não executado (wrapper/Gradle ausente).
- [ ] `./gradlew assembleDebug`: não executado.
- [ ] `./gradlew test assembleDebug`: não executado.
- [ ] Testes instrumentados, emulador e aparelho físico: não executados.
- [ ] APK Debug/Release: não gerados.

Nenhum teste ou compilação foi declarado aprovado sem execução.

## Backup: escopo da validação
A validação adicional verifica IDs, referências a sessões, resultados, confiança, proporções e datas.
A restauração continua transacional por `Room.withTransaction` e substitui integralmente as cinco tabelas.
Não foi possível executar testes de integração Room neste ambiente. Arquivos truncados/JSON malformado são
rejeitados pelo parser; versões/formato incorretos e tabelas ausentes também são rejeitados.
Limite de entrada na interface: 20 MiB. O backup não possui criptografia. Não há deduplicação semântica;
IDs repetidos dentro de uma mesma tabela agora são rejeitados.

## Funcionalidades ainda pendentes
- Wrapper oficial Gradle 8.9 e compilação real com JDK 17 + SDK 35.
- Testes de integração Room/migração e restauração sob interrupção.
- MediaProjection e Foreground Service compatível com Android 14+.
- Banca Float com overlay opt-in.
- Recognizer real, ROI, imagens de validação e confirmação humana.
- Integração completa de leituras confirmadas/rejeitadas com Room.
- Validação temporal e fora da amostra do Signal Engine; revisar a hipótese de regras do Bac Bo com a mesa/plataforma concreta (o cálculo atual assume dois dados independentes e justos por lado).
- Banca Intelligence offline e integração externa opcional segura.
- TextToSpeech pt-BR.
- Telas avançadas, gráficos, calibração e configurações.
- Testes instrumentados, emulador, aparelho físico, APK Debug/Release e pacote final 1.0.0.

## Limitações do ambiente
Ambiente sem Gradle, sem Wrapper JAR, sem SDK Android, sem adb e com OpenJDK 21 em vez de JDK 17.
A rede DNS não permitiu obter a distribuição oficial do Gradle. Portanto não é possível comprovar compilação,
instalar APK ou executar testes Android neste ambiente.

## Próxima tarefa exata
Abrir o projeto no Android Studio com JDK 17 e Android SDK Platform 35; gerar o Gradle Wrapper oficial
(Gradle 8.9); executar `./gradlew test assembleDebug`; corrigir todos os erros reportados antes de
iniciar MediaProjection. Não iniciar serviços Android sem a primeira compilação comprovada.

## Integridade
Não foram simuladas capturas, leituras visuais, IA, voz ou previsões. Frequências observadas não permitem
inferir que um resultado está prestes a ocorrer.


## Auditoria do arquivo recebido 0.4.1
- [x] Extraído e inspecionado `ProjetoBanca_0.4.1.zip`; inventariados os 36 arquivos incluídos.
- [x] Lidos README, PROGRESSO, todos os arquivos Gradle, manifestos, fontes Kotlin e testes disponíveis.
- [x] Confirmada a preservação dos quatro módulos e das cinco entidades/tabelas Room.
- [x] Verificado que o arquivo recebido não contém Gradle Wrapper, serviço de captura, overlay, recognizer, IA ou voz; estes itens permanecem pendentes.

## Continuidade adicional 0.4.2
- [x] Implementado intervalo de confiança de Wilson para proporções binomiais, com validação de entradas e níveis de confiança.
- [x] Implementada comparação descritiva das proporções entre dois períodos, sem interpretação preditiva.
- [x] Corrigida a base estatística da interface: somente rodadas confirmadas entram em frequências, janelas e sinais; registros não confirmados permanecem visíveis e identificados no histórico.
- [x] Adicionados testes unitários para intervalos, amostra vazia, entradas inválidas e comparação temporal.
- [x] Atualizada a versão para 0.4.2 (versionCode 6).

## Verificação desta etapa
- [x] Revisão estática dos arquivos alterados.
- [ ] `./gradlew test`: não executado; Gradle/Wrapper ausente.
- [ ] `./gradlew assembleDebug`: não executado; Gradle/Wrapper e Android SDK ausentes.
- [ ] Testes instrumentados e em dispositivo: não executados.
- [ ] Compilação Kotlin/Android: não comprovada.

## Próxima tarefa exata
Obter Gradle Wrapper oficial e ambiente JDK 17 + Android SDK 35; executar `./gradlew test assembleDebug`. Após corrigir erros de compilação, implementar captura MediaProjection/Foreground Service com permissões Android 14+ e testes instrumentados.


## Continuidade adicional 0.4.3 — 2026-11-26
- [x] Extraído e auditado o ZIP obrigatório 0.4.2; examinados README, PROGRESSO, configurações Gradle, manifestos, fontes Kotlin, DAOs, entidades, migração e testes.
- [x] Confirmados os módulos `app`, `core`, `database` e `statistics` e as cinco tabelas Room.
- [x] Reforçado `RoundsCsv`: agora aceita BOM UTF-8, CRLF, campos entre aspas com quebras de linha e aspas duplicadas; rejeita aspas em posições inválidas e caracteres após aspas fechadas.
- [x] Adicionados testes CSV para campos multilinha, BOM/CRLF e entradas com aspas malformadas.
- [x] Corrigido teste preexistente de alternâncias: para A,A,V,E,E há duas transições (A→V e V→E), não três.
- [x] Adicionado `.github/workflows/android-ci.yml` com JDK 17, Gradle 8.9, Android SDK 35, `gradle test`, `gradle assembleDebug` e upload de relatórios/APK.
- [x] Executadas verificações independentes com `kotlinc`: quatro verificações CSV e cinco verificações estatísticas passaram.
- [x] Incrementada versão de trabalho para 0.4.3 (`versionCode` 7), preservando a base 0.4.2.
- [ ] `./gradlew test`: não executado — Gradle Wrapper ausente e distribuição Gradle inacessível por falha DNS.
- [ ] `./gradlew assembleDebug` / `assembleRelease`: não executados — Gradle e Android SDK ausentes.
- [ ] Testes JUnit Gradle, Room instrumentados, emulador e aparelho físico: não executados.
- [ ] APK Debug/Release: não gerados.

### Auditoria de implementação — limites confirmados
- `MainActivity` contém UI Compose básica para início, estatísticas e histórico, registro manual, CSV e backup; não contém as nove telas completas solicitadas.
- `DatabaseBackup` codifica/decodifica cinco tabelas, valida IDs/relações/valores e a restauração na UI usa `Room.withTransaction`. Não há testes de integração Room nem simulação de interrupção da transação nesta etapa.
- `BancaDatabase` declara migração aditiva 1→2; não foram encontrados testes instrumentados da migração.
- Não há implementação de `MediaProjection`, Foreground Service, `SYSTEM_ALERT_WINDOW`, `ImageReader`, ROI ou reconhecimento visual.
- Não há implementação de Banca Intelligence, integração API, TextToSpeech ou relatórios de avaliação de sinais fora da amostra.
- O motor de sinais atual continua sendo um critério histórico simples e experimental; não foi promovido a previsão.

### GitHub e ambiente
- O ZIP não contém diretório `.git`, branch, histórico de commits ou endereço remoto. Nenhum acesso autorizado a repositório foi fornecido nesta sessão; por isso não foi possível criar branch, commit ou Pull Request.
- Workflow CI preparado localmente para ser executado quando o projeto for publicado em um repositório GitHub.
- Ambiente disponível: OpenJDK 21; JDK 17, Gradle, Android SDK e `adb` não encontrados.
- Tentativa de acesso a `services.gradle.org` falhou por resolução DNS. Não foi incluído Gradle Wrapper falso.

### Próxima tarefa exata
Publicar a pasta `ProjetoBanca` em uma branch de trabalho de um repositório GitHub autorizado e executar o workflow `Android CI`. Corrigir quaisquer falhas reais de Gradle/Kotlin/Room antes de iniciar a implementação de `MediaProjection` e Foreground Service. Para sincronização remota são necessários a URL do repositório e autorização de escrita (idealmente via integração GitHub ou token com escopo mínimo, nunca incluído no ZIP).

## Continuidade adicional 0.4.4 — captura e Banca Intelligence offline

- [x] Base de trabalho atualizada a partir do arquivo recebido `ProjetoBanca_0.4.3.zip` (não reiniciado; módulos existentes preservados).
- [x] Criado `ScreenCaptureService` com MediaProjection, Foreground Service, notificação contínua, VirtualDisplay, ImageReader e processamento de callbacks em HandlerThread.
- [x] Consentimento de captura é solicitado pelo fluxo oficial Android; serviço é iniciado apenas com autorização retornada.
- [x] Botões Iniciar captura/Parar adicionados à tela inicial.
- [x] Implementado descarte dos frames adquiridos: nesta versão não há armazenamento de imagens, OCR, detecção de cor ou reconhecimento automático. A captura real ainda precisa de validação em aparelho.
- [x] Adicionada Banca Intelligence local (offline), com resumo das frequências confirmadas, janela de até 20 registros, alternâncias, sequência máxima e último resultado.
- [x] Interface IA com campo de pergunta e resposta local para temas de histórico, frequência, sequências e limites de previsibilidade.
- [x] Testes unitários escritos para histórico vazio, transparência de não previsão e perguntas sobre próxima rodada.
- [x] Manifesto atualizado com permissões de Foreground Service e tipo `mediaProjection`; serviço não exportado.
- [x] Incrementada versão para 0.4.4 (versionCode 8).
- [ ] Testes Gradle/JUnit não executados: ambiente sem Gradle/Wrapper e SDK Android.
- [ ] Compilação Android, validação Android 14/15, aparelho físico e emulador não executados.
- [ ] Captura e reconhecimento visual ainda não integrados às entidades Room; OCR/ROI, classificação azul/vermelho/empate e confirmação manual continuam pendentes.
- [ ] Banca Intelligence atual é heurística offline baseada em regras e estatística descritiva, não um modelo de linguagem; integração online/API permanece pendente.

### Próxima tarefa
Validar build e permissões no Android Studio/CI. Em seguida implementar calibração/ROI e reconhecedor de cores com exemplos reais e revisão humana; conectar leituras aceitas às entidades Room. Expandir a IA offline para análise por período e explicação de métricas sem transformar padrões históricos em previsão.

# CONTINUIDADE ATUAL — 0.4.4 (prioridade: Captura + IA)

Arquivo de base nesta etapa: `ProjetoBanka_0.4.3.zip`? Correção: o arquivo enviado é `ProjetoBanka_0.4.3.zip`? O ZIP extraído foi identificado como `ProjetoBanca_0.4.3.zip`; a estrutura do projeto original foi preservada.


## Captura implementada (primeira etapa)
- Service dedicado `ScreenCaptureService`, não exportado, tipo `mediaProjection`.
- Solicitação de consentimento via `MediaProjectionManager` pela Activity.
- Foreground notification persistente e permissões exigidas do FGS MediaProjection.
- `VirtualDisplay` + `ImageReader` para obter quadros da tela.
- Callback de imagem em `HandlerThread`; quadros adquiridos e descartados, sem armazenamento.
- Controle inicial Iniciar/Parar na tela Início.
- A captura não está validada em Android físico ou emulador e o recognizer não está implementado.

## Banca Intelligence offline
- Novo componente `OfflineIntelligence`, sem rede, API externa ou modelo generativo.
- Resumo de frequências e percentuais do histórico confirmado, janela recente (até 20), alternâncias, sequência máxima e último resultado.
- Comparação descritiva dos 10 resultados mais recentes com os 10 anteriores quando há pelo menos 20.
- Interface inicial de perguntas e respostas baseada em regras para histórico/frequência, sequência/alternância e perguntas de previsão (responde com cautela e sem previsão).
- 3 testes JUnit adicionados para histórico vazio, transparência de não previsão e resposta a pergunta sobre próximo resultado.
- Componente puro Kotlin compilado com `kotlinc`; 3 smoke checks executados e aprovados nesta sessão.

## Evidências e bloqueios
- [x] Compilação standalone de `StatisticsEngine.kt` + `OfflineIntelligence.kt` via `kotlinc`.
- [x] 3 smoke checks funcionais do componente offline passaram.
- [x] Manifesto XML validado com parser.
- [ ] Gradle/JUnit Android não executados: Gradle e Gradle Wrapper não existem neste ambiente.
- [ ] APK Debug/Release, testes instrumentados, emulador e aparelho não testados.
- [ ] Teste MediaProjection real não executado.

## Limites desta entrega
Esta é uma implementação parcial, não a versão final 1.0.0. A captura é infraestrutura de obtenção de frames e ainda não realiza ROI, reconhecimento de cores, deduplicação, persistência ou confirmação visual. A “IA” é análise offline baseada em regras, não um LLM; API externa não foi configurada. A interface não tem integração de overlay, e a captura precisa ser verificada em aparelho Android.

## Próximo passo recomendado
Compilar pelo GitHub Actions com JDK 17/Android SDK 35 e corrigir qualquer erro. Depois: validar captura em aparelho, implementar calibração ROI e classificador de cores com imagens de teste e revisão manual; só então conectar leituras confiáveis ao Room. Expandir Intelligence com análise por janelas/períodos e relatórios explicativos offline.


## Continuidade 0.4.5 — foco restrito em captura e IA offline (2026-11-26)

### Auditoria do ZIP recebido
- [x] Extraído `ProjetoBanca_0.4.4.zip` e examinada a estrutura completa (99 entradas).
- [x] Lidos README, PROGRESSO, módulos Gradle, manifesto, Activity, serviço, inteligência offline, DAOs, entidades Room e testes.
- [x] Preservados os módulos `app`, `core`, `database` e `statistics` e as entidades/DAOs existentes.
- [x] Confirmado que a captura 0.4.4 iniciava MediaProjection/ImageReader, mas adquiria e descartava os quadros sem analisar nenhum pixel.
- [x] Confirmado que a IA 0.4.4 apresentava estatísticas básicas; a ordem do histórico no DAO é mais recente primeiro.

### Implementado nesta rodada
- [x] Evoluído `ScreenCaptureService`: valida consentimento recebido, impede criar VirtualDisplay duplicado em uma projeção ativa, usa `START_NOT_STICKY`, registra callback de encerramento do sistema e trata falhas de inicialização.
- [x] Mantido o fluxo oficial de consentimento MediaProjection e Foreground Service com notificação persistente.
- [x] Amostragem esparsa de pixels RGBA dos quadros reais em `HandlerThread`; calcula RGB médio e dimensões sem persistir imagens ou buffers.
- [x] Telemetria agregada por broadcast explícito ao pacote do app; Activity exibe contagem de quadros, dimensões e RGB médio recebidos.
- [x] Logs de início, interrupção, falha, dimensões e encerramento adicionados para diagnóstico no Logcat.
- [x] Encerramento libera VirtualDisplay, listener/ImageReader, callback, MediaProjection e HandlerThread.
- [x] Evoluída `OfflineIntelligence`: frequências do histórico, janelas de 10/20/50, alternâncias, maior sequência, último resultado, empates, comparação dos últimos dois blocos de 10 e indicação de amostra insuficiente.
- [x] Corrigida a interpretação da ordem dos resultados para seguir `RoundDao.observeAll()` (mais recente primeiro).
- [x] Respostas sobre previsão continuam recusando inferência do próximo resultado; dados inválidos são ignorados.
- [x] Ampliados testes unitários de IA para janela recente, alternâncias/sequência, comparação com amostra mínima e valores inválidos.
- [x] Atualizados README e versão para 0.4.5 (`versionCode 9`).

### Verificação real e limitações
- [x] Inspeção estática dos arquivos alterados e conferência das dependências e manifestos.
- [ ] `./gradlew test`: não executado — ZIP não contém `gradlew`/wrapper JAR; Gradle não instalado no ambiente.
- [ ] `./gradlew assembleDebug`: não executado — Gradle/Wrapper e Android SDK ausentes.
- [x] `StatisticsEngine.kt` + `OfflineIntelligence.kt` compilados isoladamente com `kotlinc`; cinco smoke checks executados e aprovados (histórico vazio, resumo, comparação de períodos, recusa de previsão e descarte de código inválido).
- [ ] Testes JUnit/Gradle executados: não; Gradle/Wrapper ausentes.
- [ ] Testes instrumentados, emulador e aparelho físico: não executados; `adb` e SDK ausentes.
- [ ] Captura real em Android: código implementado, mas não validado em dispositivo; não declarar captura comprovada.
- [ ] APK Debug/Release: não gerados.
- [ ] GitHub Actions: workflow existe, mas não foi executado porque não há repositório remoto/autorização configurados nesta sessão.

### Escopo deliberadamente adiado
- ROI e calibração visual.
- Recognizer AZUL/VERMELHO/EMPATE e medição de confiança.
- Deduplicação/estabilidade/estados pendente-confirmado-rejeitado.
- Persistência das leituras de captura no Room e revisão manual.
- Testes Android de ciclo de vida e validação em Android 14/15.
- Etapas restantes rumo à versão 1.0.0.

### Próximo passo exato
Executar o projeto no Android Studio com JDK 17 e SDK 35, gerar o Gradle Wrapper oficial (Gradle 8.9), compilar e executar os testes. Depois validar em aparelho: conceder captura, observar a contagem de quadros/RGB na tela inicial, alternar para outro app, parar a captura e verificar os logs. Só após essa validação avançar para ROI e recognizer.


## Continuidade 0.4.6 — rodada de núcleo de visão
- Origem recebida: `ProjetoBanca_0_4_5_Captura_Intelligence.zip` (já em 0.4.5; o prompt citava 0.4.4). Sem Gradle Wrapper, sem `.git`.
- Ambiente: sem rede (DNS falha), sem Kotlin, Gradle, JDK 17, Android SDK ou adb. Nenhum build ou teste foi executado.
- [x] Etapa 1 (parcial): workflow reescrito (wrapper gerado em CI, test + debug + release, logs/relatórios/APK). NÃO executado.
- [ ] Etapa 2: serviço de captura não alterado nem validado em Android.
- [~] Etapa 3: lógica de ROI pronta (`Roi`); falta tela de calibração, persistência e uso no serviço.
- [~] Etapa 4: `ColorRecognizer` escrito; falta integrar ao serviço e medir com capturas reais.
- [~] Etapa 5: `ResultTracker` escrito; comparação pixel a pixel entre quadros não implementada (estabilidade usa a classificação).
- [ ] Etapas 6, 7 e 8: não iniciadas (Room, evolução da Intelligence, testes instrumentados).
- Versão: 0.4.6 (versionCode 10).
- Próxima tarefa exata: publicar no GitHub e rodar o workflow; corrigir erros de compilação do código novo; depois ligar `Roi` + `ColorRecognizer` + `ResultTracker` ao `ScreenCaptureService` e criar a tela de calibração.


## Continuidade 0.4.7 — 2026-11-27
- [x] Reaberto e inspecionado o ZIP original 0.4.6; 48 arquivos encontrados nos quatro módulos (`app`, `core`, `database`, `statistics`).
- [x] Reproduzido erro de compilação Kotlin em `ResultTracker.kt`: `ArrayDeque.addLast` não era resolvido pelo compilador disponível.
- [x] Corrigida a inclusão na fila de pendências para `pending.add(it)`.
- [x] Compilados os fontes Kotlin puros dos módulos `core` e `statistics` com `kotlinc`.
- [x] Teste de fumaça executado: ROI, classificação HSV com quadro sintético, fila PENDING/confirmação manual e probabilidades teóricas (575/1296, 575/1296, 146/1296).
- [x] Incrementada a versão para 0.4.7 (`versionCode` 11).
- [ ] `./gradlew test` e `./gradlew assembleDebug`: não executados; JDK 17, Gradle/Wrapper e Android SDK 35 continuam indisponíveis neste ambiente.
- [ ] Testes JUnit completos, Room/migração, instrumentados e em dispositivo Android: pendentes.
- [ ] Integração do recognizer/ROI/tracker ao serviço de captura, persistência das leituras e calibração em captura real: pendentes.
- [ ] Envio da árvore de fontes ao GitHub: ainda não realizado.

### Limites desta entrega 0.4.7
Esta atualização corrige um erro real de compilação no Kotlin puro e valida um fluxo sintético básico. Não representa a finalização do aplicativo, não comprova build Android e não mede precisão de reconhecimento em telas reais.
