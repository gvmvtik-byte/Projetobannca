package br.com.banca.app

import br.com.banca.database.*
import org.junit.Assert.assertThrows
import org.junit.Test

class DatabaseBackupValidationTest {
    private fun contents(
        rounds: List<RoundEntity> = emptyList(),
        sessions: List<SessionEntity> = emptyList(),
        readings: List<RecognitionReadingEntity> = emptyList(),
        signals: List<SignalRecordEntity> = emptyList(),
        analyses: List<AnalysisRecordEntity> = emptyList()
    ) = DatabaseBackup.Contents(rounds, sessions, readings, signals, analyses)

    @Test fun emptyBackupIsValid() {
        DatabaseBackup.validate(contents())
    }

    @Test fun duplicatePrimaryKeysAreRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            DatabaseBackup.validate(contents(rounds = listOf(
                RoundEntity(id = 1, outcome = "A", recordedAtEpochMillis = 1),
                RoundEntity(id = 1, outcome = "V", recordedAtEpochMillis = 2)
            )))
        }
    }

    @Test fun danglingSessionReferencesAreRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            DatabaseBackup.validate(contents(readings = listOf(
                RecognitionReadingEntity(id = 1, sessionId = 99, confidence = 0.9,
                    capturedAtEpochMillis = 10)
            )))
        }
    }

    @Test fun invalidRecognitionOutcomeAndConfidenceAreRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            DatabaseBackup.validate(contents(readings = listOf(
                RecognitionReadingEntity(id = 1, detectedOutcome = "X", confidence = 0.9,
                    capturedAtEpochMillis = 10)
            )))
        }
        assertThrows(IllegalArgumentException::class.java) {
            DatabaseBackup.validate(contents(readings = listOf(
                RecognitionReadingEntity(id = 1, detectedOutcome = "A", confidence = 1.5,
                    capturedAtEpochMillis = 10)
            )))
        }
    }

    @Test fun sessionEndBeforeStartIsRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            DatabaseBackup.validate(contents(sessions = listOf(
                SessionEntity(id = 1, name = "Sessão", startedAtEpochMillis = 20,
                    endedAtEpochMillis = 10)
            )))
        }
    }

    @Test fun validSessionRelationsAreAccepted() {
        DatabaseBackup.validate(contents(
            sessions = listOf(SessionEntity(id = 7, name = "Sessão", startedAtEpochMillis = 10)),
            readings = listOf(RecognitionReadingEntity(id = 2, sessionId = 7,
                detectedOutcome = "A", confidence = 0.95, capturedAtEpochMillis = 11)),
            signals = listOf(SignalRecordEntity(id = 3, sessionId = 7, strategy = "BASELINE",
                suggestedOutcome = "V", createdAtEpochMillis = 12, sampleSize = 50,
                observedShare = 0.4, state = "SEM_SINAL"))
        ))
    }
}
