package br.com.banca.app.intelligence

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OfflineIntelligenceTest {
    @Test fun emptyHistoryIsHandled() {
        assertTrue(OfflineIntelligence.analyze(emptyList()).contains("não há rodadas confirmadas"))
    }

    @Test fun reportClearlyStatesNonPrediction() {
        val text = OfflineIntelligence.analyze(listOf("A", "V", "A", "E", "V"))
        assertTrue(text.contains("n=5"))
        assertTrue(text.contains("não indicam"))
    }

    @Test fun predictionQuestionsDoNotPredict() {
        val answer = OfflineIntelligence.answer("qual o próximo?", listOf("A", "A", "V"))
        assertTrue(answer.contains("Não é possível prever"))
    }

    @Test fun lastTenUsesNewestFirstOrder() {
        val newestFirst = listOf("E") + List(10) { "A" }
        val answer = OfflineIntelligence.answer("frequência das últimas 10", newestFirst)
        assertTrue(answer.contains("Azul 10"))
        assertTrue(answer.contains("Empate 0"))
    }

    @Test fun alternationsAreReported() {
        val answer = OfflineIntelligence.answer("quantas alternâncias?", listOf("A", "V", "A", "A"))
        assertTrue(answer.contains("2 alternância(s)"))
    }

    @Test fun longestStreakIsReported() {
        val answer = OfflineIntelligence.answer("qual a maior sequência?", listOf("A", "V", "A", "A"))
        assertTrue(answer.contains("2 resultado(s)"))
    }

    @Test fun comparisonRequiresTwentyConfirmedResults() {
        val answer = OfflineIntelligence.answer("compare os períodos", List(19) { "A" })
        assertTrue(answer.contains("necessários pelo menos 20"))
    }

    @Test fun invalidValuesAreNotCounted() {
        val summary = OfflineIntelligence.summarize(listOf("A", "?", "V", "E"))
        assertEquals(3, summary.total)
        assertEquals(1, summary.blue)
        assertEquals(1, summary.red)
        assertEquals(1, summary.tie)
    }
}
