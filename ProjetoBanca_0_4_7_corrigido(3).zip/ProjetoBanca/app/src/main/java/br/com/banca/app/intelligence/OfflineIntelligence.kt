package br.com.banca.app.intelligence

import br.com.banca.statistics.StatisticsEngine
import java.util.Locale

/**
 * Offline descriptive intelligence over confirmed outcomes in newest-first order, matching RoundDao.observeAll().
 * This component deliberately does not forecast independent game outcomes.
 */
object OfflineIntelligence {
    private val validCodes = setOf("A", "V", "E")

    data class Summary(
        val total: Int,
        val blue: Int,
        val red: Int,
        val tie: Int,
        val alternations: Int,
        val longestStreak: Int,
        val latest: String?
    )

    fun summarize(outcomes: List<String>): Summary {
        val valid = outcomes.filter { it in validCodes }
        val counts = StatisticsEngine.count(valid)
        val window = StatisticsEngine.window(valid, valid.size.coerceAtLeast(1))
        return Summary(
            total = valid.size,
            blue = counts.blue,
            red = counts.red,
            tie = counts.tie,
            alternations = window.alternations,
            longestStreak = window.longestStreak,
            latest = valid.firstOrNull()
        )
    }

    fun analyze(outcomes: List<String>): String {
        val valid = outcomes.filter { it in validCodes }
        if (valid.isEmpty()) {
            return "Ainda não há rodadas confirmadas para analisar. Registre resultados ou importe um CSV."
        }
        val counts = StatisticsEngine.count(valid)
        return buildString {
            append("Resumo offline do histórico confirmado (n=${counts.total}).\n")
            append(formatCounts("Histórico completo", counts.blue, counts.red, counts.tie, counts.total))
            listOf(10, 20, 50).forEach { size ->
                val sample = valid.take(size)
                if (sample.isNotEmpty()) {
                    val c = StatisticsEngine.count(sample)
                    val w = StatisticsEngine.window(sample, sample.size)
                    append("\nÚltimas $size: ${sample.size} observações. ")
                    append(formatCounts("", c.blue, c.red, c.tie, c.total).trim())
                    append(" Alternâncias: ${w.alternations}; maior sequência: ${w.longestStreak}.")
                } else {
                    append("\nÚltimas $size: dados insuficientes (0 observações).")
                }
            }
            append("\n")
            append(periodComparison(valid))
            append("\nÚltimo resultado registrado: ${label(valid.first())}.")
            if (valid.size < 30) append("\nAmostra pequena (menos de 30 observações): estimativas são instáveis.")
            append("\nEstes números descrevem somente o passado; não indicam qual resultado está prestes a ocorrer.")
        }
    }

    fun answer(question: String, outcomes: List<String>): String {
        val q = question.trim().lowercase(Locale.ROOT)
        val valid = outcomes.filter { it in validCodes }
        if (q.isEmpty()) {
            return "Digite uma pergunta sobre o histórico. Posso consultar frequências, últimas 10/20/50 rodadas, alternâncias, sequências e períodos."
        }
        if (valid.isEmpty()) return analyze(valid)

        val requestedWindow = when {
            Regex("\\b50\\b").containsMatchIn(q) -> 50
            Regex("\\b20\\b").containsMatchIn(q) -> 20
            Regex("\\b10\\b").containsMatchIn(q) -> 10
            else -> null
        }
        val sample = requestedWindow?.let { valid.take(it) } ?: valid
        val counts = StatisticsEngine.count(sample)
        val window = StatisticsEngine.window(sample, sample.size)

        return when {
            q.contains("próxim") || q.contains("proxim") || q.contains("previs") || q.contains("vai sair") ->
                "Não é possível prever o próximo resultado com base nas rodadas anteriores. Frequências e sequências são descrições históricas, não garantias.\n\n${analyze(valid)}"
            q.contains("altern") ->
                "Foram observadas ${window.alternations} alternância(s) em ${sample.size} resultado(s)${requestedWindow?.let { " da janela solicitada de $it" } ?: ""}. Isso não implica tendência futura."
            q.contains("maior sequência") || q.contains("maior sequencia") || q.contains("sequência máxima") || q.contains("sequencia maxima") ->
                "A maior sequência consecutiva na amostra analisada foi ${window.longestStreak} resultado(s)."
            q.contains("últimos") || q.contains("ultimos") || q.contains("frequ") || q.contains("percent") || q.contains("quantas vezes") ->
                "Frequências observadas em ${sample.size} resultado(s):\n${formatCounts("Janela", counts.blue, counts.red, counts.tie, counts.total)}"
            q.contains("empate") ->
                "Empates: ${counts.tie} de ${counts.total} resultado(s) (${percent(counts.tie, counts.total)}%) na amostra analisada."
            q.contains("compare") || q.contains("período") || q.contains("periodo") ->
                periodComparison(valid)
            q.contains("último") || q.contains("ultimo") ->
                "O resultado mais recente registrado foi ${label(valid.first())}."
            else ->
                "Posso responder sobre frequência, últimas 10/20/50 rodadas, alternâncias, maior sequência e comparação de períodos.\n\n${analyze(valid)}"
        }
    }

    private fun periodComparison(valid: List<String>): String {
        if (valid.size < 20) {
            return "Comparação de períodos indisponível: são necessários pelo menos 20 resultados confirmados; há ${valid.size}."
        }
        val last20 = valid.take(20)
        val recent = StatisticsEngine.count(last20.take(10))
        val previous = StatisticsEngine.count(last20.drop(10).take(10))
        return buildString {
            append("Comparação dos 10 mais recentes com os 10 imediatamente anteriores (dentro dos últimos 20):\n")
            append("Mais recentes: ${formatCounts("", recent.blue, recent.red, recent.tie, recent.total).trim()}\n")
            append("Anteriores: ${formatCounts("", previous.blue, previous.red, previous.tie, previous.total).trim()}")
        }
    }

    private fun formatCounts(title: String, blue: Int, red: Int, tie: Int, total: Int): String {
        val prefix = if (title.isBlank()) "" else "$title: "
        return prefix + "Azul $blue (${percent(blue, total)}%), Vermelho $red (${percent(red, total)}%), Empate $tie (${percent(tie, total)}%)."
    }

    private fun percent(value: Int, total: Int): String =
        if (total == 0) "0.0" else String.format(Locale.ROOT, "%.1f", value * 100.0 / total)

    private fun label(code: String): String = when (code) {
        "A" -> "AZUL"
        "V" -> "VERMELHO"
        else -> "EMPATE"
    }
}
