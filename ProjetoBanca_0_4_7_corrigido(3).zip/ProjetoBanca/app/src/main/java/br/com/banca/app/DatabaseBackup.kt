package br.com.banca.app

import br.com.banca.database.*
import org.json.JSONArray
import org.json.JSONObject

/** Versioned, validated JSON backup covering every Room table (not only rounds). */
object DatabaseBackup {
    private const val FORMAT = "BANCA2_BACKUP"
    private const val VERSION = 1

    fun encode(
        rounds: List<RoundEntity>, sessions: List<SessionEntity>, readings: List<RecognitionReadingEntity>,
        signals: List<SignalRecordEntity>, analyses: List<AnalysisRecordEntity>
    ): String = JSONObject().apply {
        put("format", FORMAT); put("version", VERSION); put("createdAtEpochMillis", System.currentTimeMillis())
        put("rounds", JSONArray().apply { rounds.forEach { put(JSONObject().put("id",it.id).put("outcome",it.outcome).put("at",it.recordedAtEpochMillis).put("source",it.source).put("confirmed",it.confirmed)) } })
        put("sessions", JSONArray().apply { sessions.forEach { put(JSONObject().put("id",it.id).put("name",it.name).put("started",it.startedAtEpochMillis).put("ended",it.endedAtEpochMillis ?: JSONObject.NULL).put("notes",it.notes)) } })
        put("readings", JSONArray().apply { readings.forEach { put(JSONObject().put("id",it.id).put("sessionId",it.sessionId ?: JSONObject.NULL).put("outcome",it.detectedOutcome ?: JSONObject.NULL).put("confidence",it.confidence).put("at",it.capturedAtEpochMillis).put("status",it.status).put("details",it.details)) } })
        put("signals", JSONArray().apply { signals.forEach { put(JSONObject().put("id",it.id).put("sessionId",it.sessionId ?: JSONObject.NULL).put("strategy",it.strategy).put("suggested",it.suggestedOutcome ?: JSONObject.NULL).put("at",it.createdAtEpochMillis).put("sample",it.sampleSize).put("share",it.observedShare ?: JSONObject.NULL).put("state",it.state).put("evaluated",it.evaluatedOutcome ?: JSONObject.NULL).put("evaluatedAt",it.evaluatedAtEpochMillis ?: JSONObject.NULL)) } })
        put("analyses", JSONArray().apply { analyses.forEach { put(JSONObject().put("id",it.id).put("at",it.createdAtEpochMillis).put("type",it.analysisType).put("title",it.title).put("content",it.content)) } })
    }.toString(2)

    data class Contents(val rounds: List<RoundEntity>, val sessions: List<SessionEntity>, val readings: List<RecognitionReadingEntity>, val signals: List<SignalRecordEntity>, val analyses: List<AnalysisRecordEntity>)

    fun decode(raw: String): Contents {
        require(raw.length <= 20_000_000) { "Backup excede o limite de 20 MB" }
        val root = JSONObject(raw)
        require(root.optString("format") == FORMAT) { "Formato de backup desconhecido" }
        require(root.optInt("version", -1) == VERSION) { "Versão de backup não suportada" }
        fun array(key: String) = root.optJSONArray(key) ?: throw IllegalArgumentException("Tabela ausente: $key")
        fun nullableLong(o: JSONObject, key: String): Long? = if (o.isNull(key)) null else o.getLong(key)
        val rounds = array("rounds").objects().map { RoundEntity(it.getLong("id"), it.getString("outcome").also { v -> require(v in setOf("A","V","E")) }, it.getLong("at"), it.getString("source"), it.getBoolean("confirmed")) }
        val sessions = array("sessions").objects().map { SessionEntity(it.getLong("id"),it.getString("name"),it.getLong("started"),nullableLong(it,"ended"),it.getString("notes")) }
        val readings = array("readings").objects().map { RecognitionReadingEntity(it.getLong("id"),nullableLong(it,"sessionId"),if(it.isNull("outcome")) null else it.getString("outcome"),it.getDouble("confidence"),it.getLong("at"),it.getString("status"),it.getString("details")) }
        val signals = array("signals").objects().map { SignalRecordEntity(it.getLong("id"),nullableLong(it,"sessionId"),it.getString("strategy"),if(it.isNull("suggested")) null else it.getString("suggested"),it.getLong("at"),it.getInt("sample"),if(it.isNull("share")) null else it.getDouble("share"),it.getString("state"),if(it.isNull("evaluated")) null else it.getString("evaluated"),nullableLong(it,"evaluatedAt")) }
        val analyses = array("analyses").objects().map { AnalysisRecordEntity(it.getLong("id"),it.getLong("at"),it.getString("type"),it.getString("title"),it.getString("content")) }
        val contents = Contents(rounds, sessions, readings, signals, analyses)
        validate(contents)
        return contents
    }

    internal fun validate(contents: Contents) {
        val rounds = contents.rounds
        val sessions = contents.sessions
        val readings = contents.readings
        val signals = contents.signals
        val analyses = contents.analyses
        // Room-generated primary keys must be positive and unique within each table.
        fun validateIds(table: String, ids: List<Long>) {
            require(ids.all { it > 0L }) { "Identificador inválido na tabela $table" }
            require(ids.toSet().size == ids.size) { "Identificadores duplicados na tabela $table" }
        }
        validateIds("rounds", rounds.map { it.id })
        validateIds("sessions", sessions.map { it.id })
        validateIds("readings", readings.map { it.id })
        validateIds("signals", signals.map { it.id })
        validateIds("analyses", analyses.map { it.id })

        val sessionIds = sessions.map { it.id }.toSet()
        require(sessions.all { it.endedAtEpochMillis == null || it.endedAtEpochMillis >= it.startedAtEpochMillis }) {
            "Sessão possui término anterior ao início"
        }
        require(readings.all { it.sessionId == null || it.sessionId in sessionIds }) {
            "Leitura referencia uma sessão inexistente"
        }
        require(signals.all { it.sessionId == null || it.sessionId in sessionIds }) {
            "Sinal referencia uma sessão inexistente"
        }
        require(readings.all { it.detectedOutcome == null || it.detectedOutcome in setOf("A", "V", "E") }) {
            "Resultado inválido em leitura de reconhecimento"
        }
        require(signals.all {
            (it.suggestedOutcome == null || it.suggestedOutcome in setOf("A", "V", "E")) &&
                (it.evaluatedOutcome == null || it.evaluatedOutcome in setOf("A", "V", "E"))
        }) { "Resultado inválido em registro de sinal" }
        require(readings.all { it.confidence.isFinite() && it.confidence in 0.0..1.0 }) {
            "Confiança inválida no backup"
        }
        require(signals.all {
            it.sampleSize >= 0 && (it.observedShare == null ||
                (it.observedShare.isFinite() && it.observedShare in 0.0..1.0))
        }) { "Sinal inválido no backup" }
    }
    private fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
}
