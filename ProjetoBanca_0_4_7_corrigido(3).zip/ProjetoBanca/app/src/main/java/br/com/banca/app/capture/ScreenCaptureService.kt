package br.com.banca.app.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat

/**
 * Captures user-authorized screen frames. Frames are sampled on a worker thread and
 * immediately released; no screenshot or pixel buffer is persisted.
 */
class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var projectionCallback: MediaProjection.Callback? = null
    @Volatile private var stopping = false
    private var frameCount = 0L
    private var lastNotificationFrame = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            stopSelfResult(startId)
            return START_NOT_STICKY
        }
        // A MediaProjection consent token is single-use on modern Android. Never
        // create a second VirtualDisplay from an already active projection.
        if (projection != null) return START_NOT_STICKY

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = intent?.let(::getProjectionData)
        if (resultCode != android.app.Activity.RESULT_OK || resultData == null) {
            Log.w(TAG, "Missing or denied MediaProjection consent")
            stopSelfResult(startId)
            return START_NOT_STICKY
        }

        try {
            createNotificationChannel()
            startAsForeground()
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
                ?: error("Android did not create MediaProjection")
            setupCapture()
            Log.i(TAG, "Capture started; frames will be sampled in memory only")
        } catch (error: Throwable) {
            Log.e(TAG, "Unable to start capture", error)
            stopCapture()
            stopSelfResult(startId)
        }
        return START_NOT_STICKY
    }

    private fun getProjectionData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)

    private fun startAsForeground() {
        val notification = notification("Aguardando primeiro quadro da captura")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    @Suppress("DEPRECATION")
    private fun screenMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val bounds = wm.currentWindowMetrics.bounds
            metrics.widthPixels = bounds.width()
            metrics.heightPixels = bounds.height()
            metrics.densityDpi = resources.displayMetrics.densityDpi
        } else {
            wm.defaultDisplay.getRealMetrics(metrics)
        }
        return metrics
    }

    private fun setupCapture() {
        val metrics = screenMetrics()
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        worker = HandlerThread("BancaCaptureFrames").apply { start() }
        workerHandler = Handler(checkNotNull(worker).looper)

        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                Log.i(TAG, "MediaProjection stopped by system/user")
                stopCapture()
                stopSelf()
            }
        }
        checkNotNull(projection).registerCallback(checkNotNull(projectionCallback), checkNotNull(workerHandler))

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
        imageReader?.setOnImageAvailableListener({ reader ->
            try {
                val image = reader.acquireLatestImage()
                if (image != null) image.use { processFrame(it) }
            } catch (error: IllegalStateException) {
                Log.w(TAG, "ImageReader frame unavailable", error)
            } catch (error: Throwable) {
                Log.e(TAG, "Frame processing failed", error)
            }
        }, workerHandler)

        virtualDisplay = checkNotNull(projection).createVirtualDisplay(
            "BancaCapture", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            checkNotNull(imageReader).surface, null, checkNotNull(workerHandler)
        ) ?: error("Android did not create VirtualDisplay")
        Log.i(TAG, "VirtualDisplay ${width}x$height @ ${metrics.densityDpi}dpi")
    }

    /** Reads a sparse sample from the real ImageReader frame without retaining the image. */
    private fun processFrame(image: Image) {
        if (stopping || image.planes.isEmpty()) return
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride < 4 || rowStride <= 0) return

        val stepX = (image.width / 48).coerceAtLeast(1)
        val stepY = (image.height / 48).coerceAtLeast(1)
        var red = 0L
        var green = 0L
        var blue = 0L
        var samples = 0L
        for (y in 0 until image.height step stepY) {
            val row = y * rowStride
            for (x in 0 until image.width step stepX) {
                val index = row + x * pixelStride
                if (index < 0 || index + 2 >= buffer.limit()) continue
                red += buffer.get(index).toInt() and 0xff
                green += buffer.get(index + 1).toInt() and 0xff
                blue += buffer.get(index + 2).toInt() and 0xff
                samples++
            }
        }
        if (samples == 0L) return
        frameCount++
        val avgR = (red / samples).toInt()
        val avgG = (green / samples).toInt()
        val avgB = (blue / samples).toInt()

        // Broadcast contains only frame metadata and aggregate color values, not pixels.
        sendBroadcast(Intent(ACTION_FRAME_STATS).setPackage(packageName).apply {
            putExtra(EXTRA_FRAME_COUNT, frameCount)
            putExtra(EXTRA_FRAME_WIDTH, image.width)
            putExtra(EXTRA_FRAME_HEIGHT, image.height)
            putExtra(EXTRA_AVG_RED, avgR)
            putExtra(EXTRA_AVG_GREEN, avgG)
            putExtra(EXTRA_AVG_BLUE, avgB)
            putExtra(EXTRA_SAMPLE_COUNT, samples)
        })
        if (frameCount == 1L || frameCount - lastNotificationFrame >= 60L) {
            lastNotificationFrame = frameCount
            updateNotification("Captura ativa • $frameCount quadros processados")
            Log.d(TAG, "Frame #$frameCount ${image.width}x${image.height}; avg RGB=$avgR,$avgG,$avgB")
        }
    }

    private fun stopCapture() {
        if (stopping) return
        stopping = true
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.setOnImageAvailableListener(null, null) }
        runCatching { imageReader?.close() }
        imageReader = null
        runCatching { projectionCallback?.let { projection?.unregisterCallback(it) } }
        projectionCallback = null
        runCatching { projection?.stop() }
        projection = null
        worker?.quitSafely()
        worker = null
        workerHandler = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        Log.i(TAG, "Capture stopped after $frameCount frame(s)")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Captura de tela", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("BANCA 2.0")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "br.com.banca.app.capture.STOP"
        const val ACTION_FRAME_STATS = "br.com.banca.app.capture.FRAME_STATS"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_FRAME_COUNT = "frame_count"
        const val EXTRA_FRAME_WIDTH = "frame_width"
        const val EXTRA_FRAME_HEIGHT = "frame_height"
        const val EXTRA_AVG_RED = "average_red"
        const val EXTRA_AVG_GREEN = "average_green"
        const val EXTRA_AVG_BLUE = "average_blue"
        const val EXTRA_SAMPLE_COUNT = "sample_count"
        private const val TAG = "BancaCapture"
        private const val CHANNEL_ID = "banca_screen_capture"
        private const val NOTIFICATION_ID = 2042
    }
}
