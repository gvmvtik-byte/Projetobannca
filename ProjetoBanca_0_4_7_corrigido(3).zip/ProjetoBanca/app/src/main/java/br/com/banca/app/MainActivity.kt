package br.com.banca.app

import android.os.Bundle
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.content.Context
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.room.Room
import androidx.room.withTransaction
import br.com.banca.database.BancaDatabase
import br.com.banca.database.RoundEntity
import br.com.banca.core.RoundsCsv
import br.com.banca.statistics.StatisticsEngine
import br.com.banca.app.capture.ScreenCaptureService
import br.com.banca.app.intelligence.OfflineIntelligence
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var captureLauncher: androidx.activity.result.ActivityResultLauncher<Intent>
    fun requestCapturePermission() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(manager.createScreenCaptureIntent())
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
                }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
            }
        }
        val db = Room.databaseBuilder(applicationContext, BancaDatabase::class.java, "banca.db")
            .addMigrations(BancaDatabase.MIGRATION_1_2).build()
        setContent { BancaApp(db) }
    }
}

@Composable
private fun BancaApp(db: BancaDatabase) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val rounds by db.roundDao().observeAll().collectAsState(initial = emptyList())
    val confirmedRounds = remember(rounds) { rounds.filter { it.confirmed } }
    val counts = remember(confirmedRounds) { StatisticsEngine.count(confirmedRounds.map { it.outcome }) }
    var tab by remember { mutableStateOf("INÍCIO") }
    var notice by remember { mutableStateOf("Captura requer consentimento explícito do Android; quadros são analisados em memória e não são salvos.") }
    var captureStatus by remember { mutableStateOf("Nenhum quadro recebido nesta sessão.") }
    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action == ScreenCaptureService.ACTION_FRAME_STATS) {
                    val count = intent.getLongExtra(ScreenCaptureService.EXTRA_FRAME_COUNT, 0L)
                    val width = intent.getIntExtra(ScreenCaptureService.EXTRA_FRAME_WIDTH, 0)
                    val height = intent.getIntExtra(ScreenCaptureService.EXTRA_FRAME_HEIGHT, 0)
                    val r = intent.getIntExtra(ScreenCaptureService.EXTRA_AVG_RED, 0)
                    val g = intent.getIntExtra(ScreenCaptureService.EXTRA_AVG_GREEN, 0)
                    val b = intent.getIntExtra(ScreenCaptureService.EXTRA_AVG_BLUE, 0)
                    captureStatus = "Quadros processados: $count • ${width}×${height} • RGB médio: $r,$g,$b"
                }
            }
        }
        ContextCompat.registerReceiver(
            context, receiver, IntentFilter(ScreenCaptureService.ACTION_FRAME_STATS),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }
    var aiQuestion by remember { mutableStateOf("") }
    var aiAnswer by remember { mutableStateOf(OfflineIntelligence.analyze(confirmedRounds.map { it.outcome })) }
    var pendingBackup by remember { mutableStateOf<DatabaseBackup.Contents?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            runCatching {
                val csvRows = rounds.map { RoundsCsv.Row(it.outcome, it.recordedAtEpochMillis, it.source, it.confirmed) }
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(RoundsCsv.encode(csvRows)) }
                    ?: error("Não foi possível abrir o destino")
            }.onSuccess { notice = "CSV exportado com ${rounds.size} registro(s)." }
                .onFailure { notice = "Falha na exportação: ${it.message}" }
        }
    }
    val backupExportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val payload = DatabaseBackup.encode(db.roundDao().getAll(), db.sessionDao().getAll(), db.recognitionReadingDao().getAll(), db.signalRecordDao().getAll(), db.analysisRecordDao().getAll())
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(payload) } ?: error("Não foi possível gravar o backup")
            }.onSuccess { notice = "Backup completo exportado com todas as tabelas." }.onFailure { notice = "Falha no backup: ${it.message}" }
        }
    }
    val backupImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.use { input ->
                    val output = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8 * 1024)
                    var total = 0
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        total += read
                        require(total <= 20 * 1024 * 1024) { "Backup excede o limite de 20 MB" }
                        output.write(buffer, 0, read)
                    }
                    output.toString(Charsets.UTF_8.name())
                } ?: error("Não foi possível ler o arquivo")
                DatabaseBackup.decode(raw)
            }.onSuccess { pendingBackup = it; notice = "Backup validado. Confira a prévia antes de restaurar." }
                .onFailure { notice = "Backup rejeitado: ${it.message}" }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val csv = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("Não foi possível ler o arquivo")
                    val imported = RoundsCsv.decode(csv)
                    db.roundDao().insertAll(imported.map { row -> RoundEntity(outcome = row.outcome,
                        recordedAtEpochMillis = row.recordedAtEpochMillis, source = row.source, confirmed = row.confirmed) })
                    imported.size
                }.onSuccess { notice = "Importação concluída: $it registro(s)." }
                    .onFailure { notice = "Importação cancelada: ${it.message}" }
            }
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF62A8FF), secondary = androidx.compose.ui.graphics.Color(0xFFB18CFF), background = androidx.compose.ui.graphics.Color(0xFF0B1020), surface = androidx.compose.ui.graphics.Color(0xFF151D31))) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
                Text("BANCA 2.0", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                Text("Captura e análise offline • versão 0.4.5 (captura + IA offline)", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("INÍCIO", "ESTATÍSTICAS", "HISTÓRICO", "IA").forEach { item ->
                        FilterChip(selected = tab == item, onClick = { tab = item }, label = { Text(item) })
                    }
                }
                Spacer(Modifier.height(14.dp))
                when (tab) {
                    "IA" -> {
                        Text("Banca Intelligence — modo offline", style = MaterialTheme.typography.titleLarge)
                        Text("A análise usa somente resultados confirmados armazenados no aparelho. Não envia dados para servidores.", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(value = aiQuestion, onValueChange = { aiQuestion = it }, label = { Text("Pergunte sobre seu histórico") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        Button(onClick = { aiAnswer = OfflineIntelligence.answer(aiQuestion, confirmedRounds.map { it.outcome }) }) { Text("Analisar") }
                        Spacer(Modifier.height(12.dp))
                        Card(Modifier.fillMaxWidth()) { Text(aiAnswer, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium) }
                    }
                    "ESTATÍSTICAS" -> {
                        val outcomes = confirmedRounds.map { it.outcome }
                        Text("Frequências observadas", style = MaterialTheme.typography.titleLarge)
                        StatLine("Azul", counts.blue, counts.percent(counts.blue))
                        StatLine("Vermelho", counts.red, counts.percent(counts.red))
                        StatLine("Empate", counts.tie, counts.percent(counts.tie))
                        Text("Total registrado: ${counts.total}")
                        val theoretical = br.com.banca.statistics.BacBoProbabilities.standardTwoDicePerSide()
                        Spacer(Modifier.height(12.dp))
                        Text("Probabilidade teórica (2 dados por lado)", style = MaterialTheme.typography.titleMedium)
                        Text("Azul: ${"%.2f".format(Locale.ROOT, theoretical.blue.percent)}% • Vermelho: ${"%.2f".format(Locale.ROOT, theoretical.red.percent)}% • Empate: ${"%.2f".format(Locale.ROOT, theoretical.tie.percent)}%")
                        Text("Modelo matemático para dois pares independentes de dados justos de seis faces; não é previsão nem frequência observada.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        Text("Janelas recentes", style = MaterialTheme.typography.titleMedium)
                        listOf(10, 20, 50).forEach { size ->
                            val window = StatisticsEngine.window(outcomes, size)
                            Text("Últimas $size • ${window.counts.total} registros válidos")
                            Text("A ${window.counts.blue} (${String.format(Locale.getDefault(), "%.1f", window.counts.percent(window.counts.blue))}%)  |  V ${window.counts.red} (${String.format(Locale.getDefault(), "%.1f", window.counts.percent(window.counts.red))}%)  |  E ${window.counts.tie} (${String.format(Locale.getDefault(), "%.1f", window.counts.percent(window.counts.tie))}%)")
                            Text("Alternâncias: ${window.alternations} • maior sequência: ${window.longestStreak}",
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(6.dp))
                        }
                        val signal = br.com.banca.statistics.SignalEngine.analyze(outcomes)
                        Text("Critério experimental: ${signal.state}", color = MaterialTheme.colorScheme.secondary)
                        Text(signal.explanation, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        Text("As frequências descrevem apenas o histórico observado; não predizem a próxima rodada.")
                    }
                    "HISTÓRICO" -> {
                        Text("Histórico registrado", style = MaterialTheme.typography.titleLarge)
                        LazyColumn { items(rounds, key = { it.id }) { r ->
                            ListItem(headlineContent = { Text(label(r.outcome)) }, supportingContent = { Text("${date(r.recordedAtEpochMillis)} • ${r.source} • ${if (r.confirmed) "confirmada" else "não confirmada"}") })
                            HorizontalDivider()
                        } }
                    }
                    else -> {
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("Estado da análise", style = MaterialTheme.typography.titleMedium)
                                Text("Captura de tela por MediaProjection")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = {
                                        (context as? MainActivity)?.let { activity -> activity.requestCapturePermission() }
                                    }) { Text("Iniciar captura") }
                                    OutlinedButton(onClick = { context.stopService(Intent(context, ScreenCaptureService::class.java).apply { action = ScreenCaptureService.ACTION_STOP }) }) { Text("Parar") }
                                }
                                Text("O serviço lê amostras dos quadros reais em thread de trabalho; pixels não são armazenados. O reconhecimento de resultados será uma etapa posterior.", style = MaterialTheme.typography.bodySmall)
                                Text(captureStatus, style = MaterialTheme.typography.bodySmall)
                                Text("Próximo sinal: SEM SINAL", color = MaterialTheme.colorScheme.secondary)
                                Text(notice)
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("Registrar resultado", style = MaterialTheme.typography.titleLarge)
                        Text("Use os botões somente após observar o resultado real.")
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutcomeButton("AZUL") { add(scope, db, "A") { notice = it } }
                            OutcomeButton("VERMELHO") { add(scope, db, "V") { notice = it } }
                            OutcomeButton("EMPATE") { add(scope, db, "E") { notice = it } }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("Rodadas confirmadas: ${counts.total} • total no histórico: ${rounds.size}")
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { exportLauncher.launch("banca_resultados.csv") }) { Text("Exportar CSV") }
                            OutlinedButton(onClick = { importLauncher.launch("text/*") }) { Text("Importar CSV") }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Backup completo do banco", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { backupExportLauncher.launch("banca_backup.json") }) { Text("Exportar tudo") }
                            OutlinedButton(onClick = { backupImportLauncher.launch(arrayOf("application/json", "text/*")) }) { Text("Restaurar backup") }
                        }
                        Text("Inclui resultados, sessões, leituras, sinais e análises.", style = MaterialTheme.typography.bodySmall)
                        Text(notice, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
    pendingBackup?.let { backup ->
        AlertDialog(
            onDismissRequest = { pendingBackup = null },
            title = { Text("Confirmar restauração") },
            text = { Text("Backup validado. Serão substituídos TODOS os dados atuais pelas informações do arquivo?\n\nResultados: ${backup.rounds.size}\nSessões: ${backup.sessions.size}\nLeituras: ${backup.readings.size}\nSinais: ${backup.signals.size}\nAnálises: ${backup.analyses.size}\n\nEsta ação não pode ser desfeita.") },
            confirmButton = { TextButton(onClick = {
                scope.launch {
                    runCatching { db.withTransaction {
                        db.roundDao().clearAll(); db.sessionDao().clearAll(); db.recognitionReadingDao().clearAll(); db.signalRecordDao().clearAll(); db.analysisRecordDao().clearAll()
                        db.roundDao().restoreAll(backup.rounds); db.sessionDao().restoreAll(backup.sessions); db.recognitionReadingDao().restoreAll(backup.readings); db.signalRecordDao().restoreAll(backup.signals); db.analysisRecordDao().restoreAll(backup.analyses)
                    } }.onSuccess { notice = "Restauração concluída. Todos os dados foram recuperados." }.onFailure { notice = "Falha na restauração: ${it.message}" }
                    pendingBackup = null
                }
            }) { Text("Substituir dados") } },
            dismissButton = { TextButton(onClick = { pendingBackup = null }) { Text("Cancelar") } }
        )
    }
}

@Composable private fun OutcomeButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick) { Text(text) }
}
@Composable private fun StatLine(name: String, count: Int, percent: Double) {
    ListItem(headlineContent = { Text(name) }, supportingContent = { Text("$count ocorrência(s) • ${"%.1f".format(Locale.getDefault(), percent)}%") })
}
private fun add(scope: kotlinx.coroutines.CoroutineScope, db: BancaDatabase, outcome: String, result: (String) -> Unit) {
    scope.launch {
        db.roundDao().insert(RoundEntity(outcome = outcome, recordedAtEpochMillis = System.currentTimeMillis()))
        result("Resultado ${label(outcome)} salvo no banco local.")
    }
}
private fun label(code: String) = when (code) { "A" -> "AZUL"; "V" -> "VERMELHO"; else -> "EMPATE" }
private fun date(ms: Long) = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date(ms))
