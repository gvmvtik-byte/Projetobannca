plugins { alias(libs.plugins.android.application); alias(libs.plugins.kotlin.android); alias(libs.plugins.kotlin.compose) }
android {
    namespace = "br.com.banca.app"
    compileSdk = 35
    defaultConfig { applicationId = "br.com.banca.app"; minSdk = 26; targetSdk = 35; versionCode = 11; versionName = "0.4.7" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(project(":core")); implementation(project(":database")); implementation(project(":statistics"))
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.core.ktx); implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.ui); implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3); implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.room.runtime); implementation(libs.androidx.room.ktx)
    testImplementation(libs.junit)
    debugImplementation(libs.androidx.compose.ui.tooling)
}
