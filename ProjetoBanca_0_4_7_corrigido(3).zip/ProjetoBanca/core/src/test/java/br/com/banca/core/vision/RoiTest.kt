package br.com.banca.core.vision

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RoiTest {
    @Test fun validRoiIsAccepted() = assertTrue(Roi(0.1f, 0.2f, 0.6f, 0.5f).isValid())

    @Test fun invalidRoisAreRejected() {
        assertFalse(Roi(0.6f, 0.2f, 0.1f, 0.5f).isValid())      // invertida
        assertFalse(Roi(-0.1f, 0f, 0.5f, 0.5f).isValid())       // fora da tela
        assertFalse(Roi(0f, 0f, 1.2f, 0.5f).isValid())          // fora da tela
        assertFalse(Roi(0.1f, 0.1f, 0.11f, 0.5f).isValid())     // muito pequena
        assertFalse(Roi(Float.NaN, 0f, 0.5f, 0.5f).isValid())
    }

    @Test fun scalesAcrossResolutions() {
        val roi = Roi(0.25f, 0.5f, 0.75f, 1.0f)
        assertEquals(PixelRect(270, 1200, 810, 2400), roi.toPixels(1080, 2400))
        assertEquals(PixelRect(180, 800, 540, 1600), roi.toPixels(720, 1600))
    }

    @Test fun invalidRoiOrFrameYieldsNull() {
        assertNull(Roi(0.6f, 0f, 0.1f, 0.5f).toPixels(100, 100))
        assertNull(Roi(0f, 0f, 0.5f, 0.5f).toPixels(0, 100))
        assertNull(Roi(0f, 0f, 0.05f, 0.05f).toPixels(40, 40)) // < MIN_PIXELS
    }

    @Test fun moveKeepsSizeAndStaysInsideFrame() {
        val moved = Roi(0.5f, 0.5f, 0.9f, 0.9f).moved(0.5f, -2f)
        assertEquals(0.6f, moved.left, 1e-5f)
        assertEquals(0f, moved.top, 1e-5f)
        assertEquals(0.4f, moved.width, 1e-5f)
        assertTrue(moved.isValid())
    }

    @Test fun serializationRoundTripAndMalformedText() {
        val roi = Roi(0.1f, 0.2f, 0.3f, 0.4f)
        assertEquals(roi, Roi.parse(roi.serialize()))
        assertNull(Roi.parse("abc"))
        assertNull(Roi.parse("0.1,0.2,0.3"))
        assertNull(Roi.parse("0.5,0.5,0.1,0.1"))
        assertNotNull(Roi.parse(" 0.1 , 0.1 , 0.5 , 0.5 "))
    }
}
