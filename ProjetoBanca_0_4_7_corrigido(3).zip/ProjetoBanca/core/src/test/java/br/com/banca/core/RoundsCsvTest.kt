package br.com.banca.core

import org.junit.Assert.assertEquals
import org.junit.Test

class RoundsCsvTest {
    @Test fun roundTripPreservesQuotedSource() {
        val rows = listOf(RoundsCsv.Row("A", 123L, "manual, revisado \"ok\"", true))
        assertEquals(rows, RoundsCsv.decode(RoundsCsv.encode(rows)))
    }

    @Test fun roundTripPreservesLineBreakInsideQuotedField() {
        val rows = listOf(RoundsCsv.Row("V", 456L, "importado\ncom observação", false))
        assertEquals(rows, RoundsCsv.decode(RoundsCsv.encode(rows)))
    }

    @Test fun acceptsBomAndWindowsLineEndings() {
        val csv = "\uFEFF${RoundsCsv.HEADER}\r\nA,123,MANUAL,true\r\n"
        assertEquals(listOf(RoundsCsv.Row("A", 123L, "MANUAL", true)), RoundsCsv.decode(csv))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsUnknownOutcome() {
        RoundsCsv.decode("${RoundsCsv.HEADER}\nX,123,MANUAL,true")
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsQuoteInsideUnquotedField() {
        RoundsCsv.decode("${RoundsCsv.HEADER}\nA,123,manual\"bad,true")
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsCharactersAfterClosingQuote() {
        RoundsCsv.decode("${RoundsCsv.HEADER}\nA,123,\"manual\"x,true")
    }
}
