package br.com.banca.core.vision

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResultTrackerTest {
    private fun r(o: Outcome?, c: Double = 1.0) =
        Reading(o, c, if (o == null) 0.0 else 1.0, 0.0, 0.0, 0.0, 100, o != null && c >= 0.7, "")

    private val fast = TrackerConfig(minStableFrames = 3, minStableMillis = 400, cooldownMillis = 500)

    private fun run(tracker: ResultTracker, vararg frames: Pair<Long, Reading?>): List<TrackerEvent> =
        frames.flatMap { (t, rd) -> tracker.onFrame(t, rd ?: r(null)) }

    private fun List<TrackerEvent>.count(s: ReadingState) = count { it.state == s }

    @Test fun identicalFramesConfirmOnlyOnce() {
        val tr = ResultTracker(fast)
        val ev = run(tr, *(0..5).map { it * 200L to r(Outcome.BLUE) }.toTypedArray())
        assertEquals(1, ev.count(ReadingState.DETECTED))
        assertEquals(1, ev.count(ReadingState.CONFIRMED))
    }

    @Test fun repeatedResultAfterGapRespectsCooldown() {
        val frames = (0..4).map { it * 200L to r(Outcome.BLUE) } + (5L * 200 to null) +
            (6..10).map { it * 200L to r(Outcome.BLUE) }
        val strict = run(ResultTracker(fast.copy(cooldownMillis = 5000)), *frames.toTypedArray())
        assertEquals(1, strict.count(ReadingState.CONFIRMED))
        assertEquals(1, strict.count(ReadingState.REJECTED))
        val loose = run(ResultTracker(fast.copy(cooldownMillis = 100)), *frames.toTypedArray())
        assertEquals(2, loose.count(ReadingState.CONFIRMED))
    }

    @Test fun changedResultIsNewEvent() {
        val frames = (0..4).map { it * 200L to r(Outcome.BLUE) } + (5..9).map { it * 200L to r(Outcome.RED) }
        val ev = run(ResultTracker(fast), *frames.toTypedArray())
        assertEquals(listOf(Outcome.BLUE, Outcome.RED),
            ev.filter { it.state == ReadingState.CONFIRMED }.map { it.outcome })
    }

    @Test fun animationNeverConfirmsAndFlagsUncertain() {
        val seq = listOf(Outcome.BLUE, Outcome.RED, Outcome.BLUE, Outcome.RED, Outcome.BLUE)
        val ev = run(ResultTracker(fast), *seq.mapIndexed { i, o -> i * 100L to r(o) }.toTypedArray())
        assertEquals(0, ev.count(ReadingState.CONFIRMED))
        assertTrue(ev.count(ReadingState.UNCERTAIN) >= 1)
    }

    @Test fun incompleteFrameRejectsCandidate() {
        val ev = run(ResultTracker(fast), 0L to r(Outcome.BLUE), 200L to r(Outcome.BLUE), 400L to null)
        assertEquals(0, ev.count(ReadingState.CONFIRMED))
        assertEquals(1, ev.count(ReadingState.REJECTED))
    }

    @Test fun lowConfidenceIsUncertainOnlyOnce() {
        val tr = ResultTracker(fast)
        val ev = run(tr, 0L to r(Outcome.BLUE, 0.5), 200L to r(Outcome.BLUE, 0.5), 400L to r(Outcome.BLUE, 0.5))
        assertEquals(1, ev.count(ReadingState.UNCERTAIN))
        assertEquals(0, ev.count(ReadingState.CONFIRMED))
    }

    @Test fun interruptedCaptureRejectsUnresolvedCandidate() {
        val tr = ResultTracker(fast)
        run(tr, 0L to r(Outcome.BLUE), 200L to r(Outcome.BLUE))
        val ev = tr.onCaptureInterrupted(300L)
        assertEquals(1, ev.count(ReadingState.REJECTED))
        assertEquals(1, tr.onFrame(1000L, r(Outcome.BLUE)).count(ReadingState.DETECTED))
    }

    @Test fun manualModeQueuesPendingUntilConfirmed() {
        val tr = ResultTracker(fast.copy(autoConfirm = false))
        val ev = run(tr, *(0..3).map { it * 200L to r(Outcome.RED) }.toTypedArray())
        assertEquals(0, ev.count(ReadingState.CONFIRMED))
        assertEquals(1, ev.count(ReadingState.PENDING))
        assertEquals(1, tr.pendingQueue().size)
        val c = tr.confirmPending(2000L)
        assertNotNull(c); assertEquals(ReadingState.CONFIRMED, c!!.state); assertEquals(Outcome.RED, c.outcome)
        assertNull(tr.confirmPending(2100L))
    }

    @Test fun manualRejectDropsPending() {
        val tr = ResultTracker(fast.copy(autoConfirm = false))
        run(tr, *(0..3).map { it * 200L to r(Outcome.BLUE) }.toTypedArray())
        assertEquals(ReadingState.REJECTED, tr.rejectPending(2000L)!!.state)
        assertTrue(tr.pendingQueue().isEmpty())
    }
}
