package br.com.banca.core.vision

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Quadros SINTÉTICOS de teste: validam a lógica, não a precisão sobre telas reais. */
class ColorRecognizerTest {
    private val blue = 0xFF2060FF.toInt()
    private val red = 0xFFE02020.toInt()
    private val yellow = 0xFFFFD000.toInt()
    private val gray = 0xFFCCCCCC.toInt()
    private val full = Roi(0f, 0f, 1f, 1f)

    private fun read(roi: Roi = full, w: Int = 100, h: Int = 100, px: (Int, Int) -> Int) =
        ColorRecognizer.classify(w, h, roi, pixel = px)

    @Test fun solidColorsAreRecognized() {
        assertEquals(Outcome.BLUE, read { _, _ -> blue }.outcome)
        assertEquals(Outcome.RED, read { _, _ -> red }.outcome)
        assertEquals(Outcome.TIE, read { _, _ -> yellow }.outcome)
        val r = read { _, _ -> blue }
        assertTrue(r.accepted); assertEquals(1.0, r.confidence, 1e-9)
    }

    @Test fun dominantColorWithNoiseIsAccepted() {
        val r = read { x, _ -> if (x < 80) blue else red }
        assertEquals(Outcome.BLUE, r.outcome)
        assertTrue(r.accepted)
        assertTrue(r.confidence in 0.75..0.85)
    }

    @Test fun ambiguousHalfAndHalfIsRejected() {
        val r = read { x, _ -> if (x < 50) blue else red }
        assertFalse(r.accepted)
        assertTrue(r.confidence < 0.7)
    }

    @Test fun grayFrameHasNoOutcome() {
        val r = read { _, _ -> gray }
        assertNull(r.outcome); assertFalse(r.accepted)
    }

    @Test fun onlyRoiIsRead() {
        // Fora da ROI há vermelho; dentro, azul.
        val roi = Roi(0.5f, 0.5f, 1f, 1f)
        val r = read(roi) { x, y -> if (x >= 50 && y >= 50) blue else red }
        assertEquals(Outcome.BLUE, r.outcome); assertEquals(1.0, r.confidence, 1e-9)
    }

    @Test fun invalidRoiIsRejectedWithoutReading() {
        val r = read(Roi(0.9f, 0f, 0.1f, 1f)) { _, _ -> blue }
        assertFalse(r.accepted); assertEquals(0, r.samples)
    }

    @Test fun sameRelativeRoiWorksAtAnotherResolution() {
        val roi = Roi(0.5f, 0f, 1f, 1f)
        val low = read(roi, 100, 100) { x, _ -> if (x >= 50) red else blue }
        val high = read(roi, 1000, 2000) { x, _ -> if (x >= 500) red else blue }
        assertEquals(Outcome.RED, low.outcome); assertEquals(Outcome.RED, high.outcome)
    }

    @Test fun hueHelpersHandleWraparound() {
        assertEquals(20f, ColorRecognizer.hueDistance(350f, 10f), 1e-4f)
        val hsv = FloatArray(3)
        ColorRecognizer.toHsv(255, 0, 30, hsv)
        assertTrue(hsv[0] > 340f)
    }
}
