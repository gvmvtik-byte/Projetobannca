package br.com.banca.core.vision

enum class ReadingState { DETECTED, PENDING, CONFIRMED, REJECTED, UNCERTAIN }

data class TrackerEvent(
    val state: ReadingState,
    val outcome: Outcome?,
    val confidence: Double,
    val timestampMillis: Long,
    val note: String
)

data class TrackerConfig(
    val minStableFrames: Int = 3,
    val minStableMillis: Long = 600,
    val cooldownMillis: Long = 2000,
    /** Oscilações (mudanças antes de estabilizar) que marcam a sequência como INCERTA. */
    val maxFlips: Int = 3,
    /** Se falso, resultados estáveis ficam PENDENTES até confirmação manual. */
    val autoConfirm: Boolean = true
)

/**
 * Máquina de estados que decide quando um resultado NOVO realmente apareceu.
 * Um resultado só é confirmado após estabilidade (quadros + tempo) e respeitando o cooldown.
 * Quadros idênticos seguintes ao já resolvido não geram novos eventos. Não é thread-safe:
 * use sempre a partir da mesma thread de processamento.
 */
class ResultTracker(private val config: TrackerConfig = TrackerConfig()) {
    private var candidate: Outcome? = null
    private var candidateSince = 0L
    private var stableFrames = 0
    private var resolved = false
    private var flips = 0
    private var uncertainActive = false
    private var lastConfirmedAt: Long? = null
    private val pending = ArrayDeque<TrackerEvent>()

    fun pendingQueue(): List<TrackerEvent> = pending.toList()

    fun onFrame(timestampMillis: Long, reading: Reading): List<TrackerEvent> {
        val t = timestampMillis
        val events = mutableListOf<TrackerEvent>()
        val outcome = reading.outcome
        if (!reading.accepted || outcome == null) {
            val c = candidate
            if (c != null && !resolved) {
                events += TrackerEvent(ReadingState.REJECTED, c, reading.confidence, t,
                    "Leitura incompleta ou incerta antes da estabilização")
            } else if (outcome != null && !uncertainActive) {
                events += TrackerEvent(ReadingState.UNCERTAIN, outcome, reading.confidence, t, reading.reason)
            }
            uncertainActive = outcome != null
            clearCandidate()
            return events
        }
        uncertainActive = false
        val current = candidate
        when {
            current == null -> {
                startCandidate(outcome, t)
                events += TrackerEvent(ReadingState.DETECTED, outcome, reading.confidence, t, "Novo resultado visto")
            }
            current != outcome -> {
                if (!resolved) {
                    flips++
                    events += TrackerEvent(ReadingState.REJECTED, current, reading.confidence, t,
                        "Resultado mudou antes de estabilizar")
                    if (flips == config.maxFlips) {
                        events += TrackerEvent(ReadingState.UNCERTAIN, outcome, reading.confidence, t,
                            "Oscilação de cores: possível animação")
                    }
                }
                startCandidate(outcome, t)
                events += TrackerEvent(ReadingState.DETECTED, outcome, reading.confidence, t, "Novo resultado visto")
            }
            else -> {
                stableFrames++
                if (!resolved && stableFrames >= config.minStableFrames &&
                    t - candidateSince >= config.minStableMillis
                ) events += resolve(outcome, reading.confidence, t)
            }
        }
        return events
    }

    /** Captura interrompida: candidato não resolvido é rejeitado; pendentes manuais são mantidos. */
    fun onCaptureInterrupted(timestampMillis: Long): List<TrackerEvent> {
        val c = candidate
        val events = mutableListOf<TrackerEvent>()
        if (c != null && !resolved) {
            events += TrackerEvent(ReadingState.REJECTED, c, 0.0, timestampMillis, "Captura interrompida")
        }
        clearCandidate()
        uncertainActive = false
        return events
    }

    fun confirmPending(timestampMillis: Long): TrackerEvent? {
        val e = pending.removeFirstOrNull() ?: return null
        lastConfirmedAt = timestampMillis
        return TrackerEvent(ReadingState.CONFIRMED, e.outcome, e.confidence, timestampMillis, "Confirmação manual")
    }

    fun rejectPending(timestampMillis: Long): TrackerEvent? {
        val e = pending.removeFirstOrNull() ?: return null
        return TrackerEvent(ReadingState.REJECTED, e.outcome, e.confidence, timestampMillis, "Rejeição manual")
    }

    fun reset() { clearCandidate(); pending.clear(); lastConfirmedAt = null; uncertainActive = false }

    private fun resolve(outcome: Outcome, confidence: Double, t: Long): TrackerEvent {
        resolved = true
        val last = lastConfirmedAt
        return when {
            last != null && t - last < config.cooldownMillis ->
                TrackerEvent(ReadingState.REJECTED, outcome, confidence, t, "Dentro do cooldown")
            config.autoConfirm -> {
                lastConfirmedAt = t
                flips = 0
                TrackerEvent(ReadingState.CONFIRMED, outcome, confidence, t, "Estável por ${stableFrames} quadros")
            }
            else -> TrackerEvent(ReadingState.PENDING, outcome, confidence, t, "Aguardando confirmação manual")
                .also { pending.add(it) }
        }
    }

    private fun startCandidate(outcome: Outcome, t: Long) {
        candidate = outcome; candidateSince = t; stableFrames = 1; resolved = false
    }

    private fun clearCandidate() { candidate = null; stableFrames = 0; resolved = false; flips = 0 }
}
