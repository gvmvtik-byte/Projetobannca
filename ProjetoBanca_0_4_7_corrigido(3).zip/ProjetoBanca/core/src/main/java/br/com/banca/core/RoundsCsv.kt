package br.com.banca.core

/** CSV interchange for manually confirmed round records. UTF-8, RFC-4180-style quoting. */
object RoundsCsv {
    const val HEADER = "outcome,recordedAtEpochMillis,source,confirmed"

    data class Row(val outcome: String, val recordedAtEpochMillis: Long, val source: String, val confirmed: Boolean)

    fun encode(rows: List<Row>): String = buildString {
        append(HEADER).append("\r\n")
        rows.forEach { row ->
            require(row.outcome in setOf("A", "V", "E")) { "Resultado inválido: ${row.outcome}" }
            append(row.outcome).append(',')
            append(row.recordedAtEpochMillis).append(',')
            append(quote(row.source)).append(',')
            append(row.confirmed).append("\r\n")
        }
    }

    fun decode(csv: String): List<Row> {
        val normalized = csv.removePrefix("\uFEFF")
        val records = parseRecords(normalized).filterNot { record -> record.size == 1 && record[0].isBlank() }
        require(records.isNotEmpty() && records.first().size == 4 &&
            records.first().joinToString(",") == HEADER) { "Cabeçalho CSV inválido" }
        return records.drop(1).mapIndexed { index, fields ->
            require(fields.size == 4) { "Linha ${index + 2}: quantidade de colunas inválida" }
            val outcome = fields[0].trim()
            require(outcome in setOf("A", "V", "E")) { "Linha ${index + 2}: resultado inválido" }
            val timestamp = fields[1].toLongOrNull()
                ?: throw IllegalArgumentException("Linha ${index + 2}: data inválida")
            val confirmed = fields[3].toBooleanStrictOrNull()
                ?: throw IllegalArgumentException("Linha ${index + 2}: confirmação inválida")
            Row(outcome, timestamp, fields[2], confirmed)
        }
    }

    private fun quote(value: String): String =
        if (value.any { it == ',' || it == '"' || it == '\n' || it == '\r' })
            "\"${value.replace("\"", "\"\"")}\"" else value

    /** Strict record parser: quotes may only begin a field and no characters may follow a closing quote. */
    private fun parseRecords(input: String): List<List<String>> {
        val records = mutableListOf<List<String>>()
        var fields = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var closedQuote = false
        var atFieldStart = true
        var i = 0

        fun finishField() {
            fields += field.toString()
            field.setLength(0)
            atFieldStart = true
            closedQuote = false
        }
        fun finishRecord() {
            finishField()
            records += fields
            fields = mutableListOf()
        }

        while (i < input.length) {
            val c = input[i]
            if (quoted) {
                when {
                    c == '"' && i + 1 < input.length && input[i + 1] == '"' -> {
                        field.append('"'); i++
                    }
                    c == '"' -> { quoted = false; closedQuote = true }
                    else -> field.append(c)
                }
            } else {
                when {
                    c == ',' -> finishField()
                    c == '\n' -> finishRecord()
                    c == '\r' -> {
                        if (i + 1 < input.length && input[i + 1] == '\n') i++
                        finishRecord()
                    }
                    c == '"' && atFieldStart -> { quoted = true; atFieldStart = false }
                    c == '"' -> throw IllegalArgumentException("Aspas em posição inválida no CSV")
                    closedQuote -> throw IllegalArgumentException("Conteúdo após fechamento de aspas no CSV")
                    else -> { field.append(c); atFieldStart = false }
                }
            }
            i++
        }
        require(!quoted) { "Campo CSV com aspas não finalizadas" }
        if (fields.isNotEmpty() || field.isNotEmpty() || !atFieldStart) finishRecord()
        return records
    }
}
