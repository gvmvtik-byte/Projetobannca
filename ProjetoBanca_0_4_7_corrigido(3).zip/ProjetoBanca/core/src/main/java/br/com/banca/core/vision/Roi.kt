package br.com.banca.core.vision

/** Região em pixels de um quadro (limites: left/top inclusivos, right/bottom exclusivos). */
data class PixelRect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
}

/**
 * Região de interesse em coordenadas NORMALIZADAS (0..1) relativas ao quadro.
 * Por serem relativas, independem de resolução e densidade. A orientação em que a
 * ROI foi calibrada deve ser guardada junto pela camada de persistência.
 */
data class Roi(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top

    fun isValid(minSize: Float = MIN_SIZE): Boolean =
        listOf(left, top, right, bottom).all { it.isFinite() } &&
            left >= 0f && top >= 0f && right <= 1f && bottom <= 1f &&
            width >= minSize && height >= minSize

    /** Converte para pixels do quadro atual; null se a ROI for inválida ou ficar pequena demais. */
    fun toPixels(frameWidth: Int, frameHeight: Int): PixelRect? {
        if (frameWidth <= 0 || frameHeight <= 0 || !isValid()) return null
        val l = kotlin.math.floor(left * frameWidth).toInt().coerceIn(0, frameWidth)
        val t = kotlin.math.floor(top * frameHeight).toInt().coerceIn(0, frameHeight)
        val r = kotlin.math.ceil(right * frameWidth).toInt().coerceIn(0, frameWidth)
        val b = kotlin.math.ceil(bottom * frameHeight).toInt().coerceIn(0, frameHeight)
        val rect = PixelRect(l, t, r, b)
        return if (rect.width >= MIN_PIXELS && rect.height >= MIN_PIXELS) rect else null
    }

    /** Move a região mantendo o tamanho e sem sair do quadro. */
    fun moved(dx: Float, dy: Float): Roi {
        val w = width
        val h = height
        val nl = (left + dx).coerceIn(0f, (1f - w).coerceAtLeast(0f))
        val nt = (top + dy).coerceIn(0f, (1f - h).coerceAtLeast(0f))
        return Roi(nl, nt, nl + w, nt + h)
    }

    fun serialize(): String = "$left,$top,$right,$bottom"

    companion object {
        const val MIN_SIZE = 0.02f
        const val MIN_PIXELS = 4

        /** Retorna null para texto malformado ou ROI inválida (nunca assume valores padrão). */
        fun parse(text: String): Roi? {
            val p = text.split(",").map { it.trim().toFloatOrNull() }
            if (p.size != 4 || p.any { it == null }) return null
            return Roi(p[0]!!, p[1]!!, p[2]!!, p[3]!!).takeIf { it.isValid() }
        }
    }
}
