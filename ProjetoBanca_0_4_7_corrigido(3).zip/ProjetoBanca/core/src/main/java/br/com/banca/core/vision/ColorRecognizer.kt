package br.com.banca.core.vision

enum class Outcome(val code: String) { BLUE("A"), RED("V"), TIE("E") }

/**
 * Perfil de cores de referência (matiz HSV em graus). Os valores padrão são ESTIMATIVAS
 * (azul, vermelho, amarelo) e DEVEM ser calibrados contra a tela real do jogo.
 */
data class ColorProfile(
    val blueHue: Float = 220f,
    val redHue: Float = 0f,
    val tieHue: Float = 50f,
    val hueTolerance: Float = 25f,
    val minSaturation: Float = 0.45f,
    val minValue: Float = 0.25f
)

data class RecognizerConfig(
    val profile: ColorProfile = ColorProfile(),
    val sampleGrid: Int = 24,
    /** Fração mínima de amostras coloridas na ROI para aceitar uma leitura. */
    val minColoredFraction: Double = 0.05,
    /** Dominância mínima da cor vencedora entre as amostras coloridas. */
    val minConfidence: Double = 0.7
)

/**
 * Resultado de uma leitura. `confidence` é a dominância da cor vencedora entre os pixels
 * coloridos: um escore heurístico, NÃO uma taxa de acerto medida.
 */
data class Reading(
    val outcome: Outcome?,
    val confidence: Double,
    val coloredFraction: Double,
    val blueShare: Double,
    val redShare: Double,
    val tieShare: Double,
    val samples: Int,
    val accepted: Boolean,
    val reason: String
) {
    companion object {
        fun empty(reason: String) = Reading(null, 0.0, 0.0, 0.0, 0.0, 0.0, 0, false, reason)
    }
}

object ColorRecognizer {
    /** `pixel(x, y)` devolve ARGB do quadro completo. A leitura ocorre somente dentro da ROI. */
    fun classify(
        frameWidth: Int,
        frameHeight: Int,
        roi: Roi,
        config: RecognizerConfig = RecognizerConfig(),
        pixel: (Int, Int) -> Int
    ): Reading {
        val rect = roi.toPixels(frameWidth, frameHeight) ?: return Reading.empty("ROI inválida ou fora do quadro")
        val grid = config.sampleGrid.coerceAtLeast(1)
        val stepX = (rect.width / grid).coerceAtLeast(1)
        val stepY = (rect.height / grid).coerceAtLeast(1)
        val hsv = FloatArray(3)
        val counts = IntArray(3)
        var samples = 0
        var y = rect.top
        while (y < rect.bottom) {
            var x = rect.left
            while (x < rect.right) {
                samples++
                val argb = pixel(x, y)
                toHsv((argb shr 16) and 0xFF, (argb shr 8) and 0xFF, argb and 0xFF, hsv)
                val p = config.profile
                if (hsv[1] >= p.minSaturation && hsv[2] >= p.minValue) {
                    val dB = hueDistance(hsv[0], p.blueHue)
                    val dR = hueDistance(hsv[0], p.redHue)
                    val dT = hueDistance(hsv[0], p.tieHue)
                    val best = minOf(dB, dR, dT)
                    if (best <= p.hueTolerance) {
                        when (best) { dB -> counts[0]++; dR -> counts[1]++; else -> counts[2]++ }
                    }
                }
                x += stepX
            }
            y += stepY
        }
        if (samples == 0) return Reading.empty("Nenhuma amostra na ROI")
        val colored = counts.sum()
        val coloredFraction = colored.toDouble() / samples
        if (colored == 0) {
            return Reading(null, 0.0, 0.0, 0.0, 0.0, 0.0, samples, false, "Sem pixels coloridos na ROI")
        }
        val shares = counts.map { it.toDouble() / colored }
        val top = counts.indices.maxByOrNull { counts[it] } ?: 0
        val outcome = Outcome.values()[top]
        val confidence = shares[top]
        val accepted = coloredFraction >= config.minColoredFraction && confidence >= config.minConfidence
        val reason = when {
            coloredFraction < config.minColoredFraction -> "Cobertura de cor abaixo do mínimo"
            confidence < config.minConfidence -> "Dominância abaixo do limiar (ambígua)"
            else -> "Leitura aceita"
        }
        return Reading(outcome, confidence, coloredFraction, shares[0], shares[1], shares[2], samples, accepted, reason)
    }

    internal fun hueDistance(a: Float, b: Float): Float {
        val d = kotlin.math.abs(a - b) % 360f
        return if (d > 180f) 360f - d else d
    }

    internal fun toHsv(r: Int, g: Int, b: Int, out: FloatArray) {
        val rf = r / 255f; val gf = g / 255f; val bf = b / 255f
        val max = maxOf(rf, gf, bf); val min = minOf(rf, gf, bf)
        val delta = max - min
        var hue = when {
            delta == 0f -> 0f
            max == rf -> 60f * (((gf - bf) / delta) % 6f)
            max == gf -> 60f * ((bf - rf) / delta + 2f)
            else -> 60f * ((rf - gf) / delta + 4f)
        }
        if (hue < 0f) hue += 360f
        out[0] = hue
        out[1] = if (max == 0f) 0f else delta / max
        out[2] = max
    }
}
